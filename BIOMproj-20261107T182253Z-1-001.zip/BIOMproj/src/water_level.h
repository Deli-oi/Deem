#ifndef WATER_LEVEL_H
#define WATER_LEVEL_H

#include <Arduino.h>

class WaterLevel {
public:
    WaterLevel();
    void setup();
    void update();
    void updateNonblocking();
    float getDistance() const;
    
private:
    float distance_ = 0;
    
    // Non-blocking state machine (matching working code's states)
    enum UpdateState {
        IDLE,
        TRIGGER_SENT,
        WAITING_FOR_DATA
    };
    
    UpdateState updateState_ = IDLE;
    unsigned long stateStartTime_ = 0;
    unsigned long lastUpdateTime_ = 0;
    static constexpr unsigned long UPDATE_INTERVAL = 3000; // Increased from 500ms in old code
    
    size_t readReg(uint8_t reg, uint8_t* pBuf, size_t size);
    bool readRegNonblocking(uint8_t reg, uint8_t* pBuf, size_t size);
    bool writeReg(uint8_t reg, const uint8_t* pBuf, size_t size);
};

#endif // WATER_LEVEL_H
