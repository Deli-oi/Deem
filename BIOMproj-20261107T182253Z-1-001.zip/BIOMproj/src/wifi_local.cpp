//implementation file 
//function definitions 
#include "wifi_local.h"
#include "parameters.h"
#include "wifi_app.h"

//expand on functions here
esp_now_peer_info_t Wifi_Local::peerInfo = {};

//start disconnected
bool Wifi_Local::wifiConnected = false;
bool Wifi_Local::peerAdded = false;
Wifi_Local::ReceiveCallback Wifi_Local::userReceiveCallback = nullptr;

void Wifi_Local::begin(){
    initESPNow();
}
//wifi
void Wifi_Local::initWiFi(){
    String SSID = wifi.getWiFiSSID();
    String Password = wifi.getWiFiPassword();
    WiFi.mode(WIFI_STA);
    WiFi.begin(SSID,Password);
    wifiConnected = true;
}
//espnow
void Wifi_Local::initESPNow(){
      if (esp_now_init() != ESP_OK) {
        Serial.println("Error initializing ESP-NOW"); //delay and redo
        return;
    }
    esp_now_register_recv_cb(Wifi_Local::onReceive);
}
//set peer using mac addr
void Wifi_Local::setPeer(const uint8_t *peer_addr) {
    memcpy(peerInfo.peer_addr, peer_addr, MAC_ADDR_LEN);
    peerInfo.channel = 0;
    peerInfo.encrypt = false;
    if (esp_now_add_peer(&peerInfo) == ESP_OK) {
        peerAdded = true;
    }
}


//send data
void Wifi_Local::sendData(const uint8_t *peer_addr, const uint8_t *data, size_t len) {
   //connect to peer
   if (!peerAdded) {
        memcpy(peerInfo.peer_addr, peer_addr, MAC_ADDR_LEN);
        peerInfo.channel = 0;
        peerInfo.encrypt = false;// what happens if this is true?

        if (esp_now_add_peer(&peerInfo) != ESP_OK) {
            Serial.println("Failed to add peer");
            return;
        }
        peerAdded = true;
    }
    //send and check status of data
    esp_err_t result = esp_now_send(peer_addr, data, len);
    if (result != ESP_OK) {
        Serial.print("Error sending data: ");
        Serial.println(result);
    }
}
//receive data
void Wifi_Local::onReceive(const uint8_t *mac, const uint8_t *incomingData, int len) {
    if (userReceiveCallback) {
        userReceiveCallback(mac, incomingData, len);
    } else {
        Serial.print("Received data");
    }
}

//simple bool for connection status
bool Wifi_Local::isConnected() const {
    return wifiConnected;
}

//receive espnow signal
void Wifi_Local::setReceiveCallback(ReceiveCallback cb) {
    userReceiveCallback = cb;
}
