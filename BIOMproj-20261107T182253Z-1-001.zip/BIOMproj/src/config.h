// AIO credentials
#define IO_USERNAME "ecologic"
#define IO_KEY      "aio_otvh897kyJI69uEnBIMFQjNaNjPf"

// Define empty default credentials - will be overridden by stored values
#define WIFI_SSID   ""
#define WIFI_PASS   ""