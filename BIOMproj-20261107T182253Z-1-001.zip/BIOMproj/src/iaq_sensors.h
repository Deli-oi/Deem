#ifndef IAQ_SENSORS_H
#define IAQ_SENSORS_H

#include <Arduino.h>
#include <Adafruit_PM25AQI.h>
#include <Adafruit_SGP30.h>
#include <SensirionI2cScd4x.h>

// IAQSensors class definition
class IAQSensors {
public:
    // Constructor
    IAQSensors();
    
    // Initialize sensors
    void begin();
    
    // Update sensor readings
    void update();
    void updateNonblocking();
    
    // Get sensor values
    uint16_t getTVOC() const { return tvoc_; }
    uint16_t getECO2() const { return eco2_; }
    uint16_t getCO2() const { return co2_; }
    float getTemperature() const { return temperature_; }
    float getHumidity() const { return humidity_; }
    uint16_t getPM25() const { return pmData_.pm25_standard; }
    const PM25_AQI_Data& getPMData() const { return pmData_; }
    
    // Check sensor availability
    bool isSGPAvailable() const { return sgpAvailable_; }
    bool isPM25Available() const { return pm25Available_; }
    bool isSCD4xAvailable() const { return scd4xAvailable_; }
    
private:
    // Sensor instances
    Adafruit_SGP30 sgp_;
    Adafruit_PM25AQI aqi_;
    SensirionI2cScd4x scd4x_;
    
    // Sensor data
    uint16_t tvoc_;
    uint16_t eco2_;
    PM25_AQI_Data pmData_;
    uint16_t co2_;
    float temperature_;
    float humidity_;
    
    // Sensor availability flags
    bool sgpAvailable_;
    bool pm25Available_;
    bool scd4xAvailable_;
    
    // Baseline values for SGP30
    uint16_t tvocBase_;
    uint16_t eco2Base_;
    int baselineCounter_;
    
    // Timing variables
    unsigned long lastSCD4xUpdate_;
    unsigned long lastUpdate_;
    unsigned long lastNonblockingUpdate_;
    bool updateInProgress_;
    
    // Helper methods
    uint32_t getAbsoluteHumidity(float temperature, float humidity);
    void updateSGP30();
    void updatePM25();
    void updateSCD4x();
};

// Global instance declaration
extern IAQSensors iaqSensors;

// Backward compatibility - global variables that reference the class instance
extern uint16_t iaq_tvoc;
extern uint16_t iaq_eco2;
extern uint16_t iaq_co2;
extern float iaq_temp;
extern float iaq_humidity;
extern PM25_AQI_Data iaq_pmData;

#endif // IAQ_SENSORS_H
