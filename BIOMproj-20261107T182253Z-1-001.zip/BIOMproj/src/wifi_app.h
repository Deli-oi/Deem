#ifndef WIFI_APP_H
#define WIFI_APP_H

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <PubSubClient.h>

// Raw MQTT configuration for Adafruit IO
#define MQTT_SERVER "io.adafruit.com"
#define MQTT_PORT 1883  // Plain MQTT port (no SSL)
#define MQTT_BUFFER_SIZE 512

class Wifi {
public:
    Wifi();
    ~Wifi();
    
    void begin();
    void update();
    bool getIsInSetupMode() const;
    bool isMQTTConnected() const;
    String getWiFiSSID() const;
    String getWiFiPassword() const;
    
    // WiFi setup methods
    void startWiFiSetupMode();
    void stopWiFiSetupMode();
    
    // Credentials management
    bool hasWiFiCredentials();
    bool saveWiFiCredentials(const char* ssid, const char* password);
    bool clearWiFiCredentials();
    bool checkWiFiConnection(int timeout);
    
    // Factory reset
    void resetToFactorySettings();
    
    // MQTT debugging
    void debugMQTT();
    
    // Data publishing
    void saveReceiveData();

private:
    // Web server for setup mode
    WebServer server_;
    DNSServer dnsServer_;
    bool isInSetupMode_;
    
    // WiFi credentials
    Preferences prefs_;
    String savedSSID_;
    String savedPassword_;
    
    // Raw MQTT client
    WiFiClient wifiClient_;
    PubSubClient mqttClient_;
    bool mqttConnected_;
    unsigned long lastMqttAttempt_;
    
    // MQTT topics
    String dataTopicName_;
    String commandTopicName_;
    
    // Web server route handlers
    void setupWebServerRoutes();
    void handleRootRequest();
    void handleSaveRequest();
    void handleScanRequest();
    void handleNotFound();
    void handleSaveCredentials();
    void handleNetworkScan();
    
    // Initialization
    void initWiFi();
    void initializeMQTT();
    void initializePreferences();
    
    // Runtime methods
    void runIO();
    void connectToMQTT();
    void checkMQTTStatus();
    
    // MQTT callbacks and message handling
    static void mqttCallback(char* topic, byte* payload, unsigned int length);
    void handleMqttMessage(const char* topic, const char* message);
    void processCommand(const char* command);
    
    // Command handling without callbacks
    void processDeferredCommands();
    void processLEDCommand(const char* cmd);
    void processPumpCommand(const char* cmd);
    void processFanCommand(const char* cmd);
    void processScheduleCommands(const char* jsonStr);
    void processFactoryResetCommand(const char* resetType);
    
    // Command polling state
    unsigned long lastCommandPoll_;
    bool pendingCommandsFlag_;
    char pendingCommandsBuf_[256];
};

// Global instance declaration
extern Wifi wifi;

#endif // WIFI_APP_H