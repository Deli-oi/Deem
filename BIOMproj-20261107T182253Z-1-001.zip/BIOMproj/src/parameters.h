#ifndef PARAMETERS_H
#define PARAMETERS_H

#include <stdint.h> // For uint32_t type definition

// ------------------- Pin Assignments -------------------
// LED Growlight
static constexpr int LED_INPUT_PIN_1 = 4;   // Input pin to monitor the signal for LED control
static constexpr int LED_INPUT_PIN_2 = 21;  // Input pin to monitor the signal for LED control
static constexpr int LED_MOSFET_PIN  = 15;  // Output pin to drive the MOSFET/LED

// Pump Control
static constexpr int PUMP_TOGGLE_PIN_1 = 19; // Toggle switch input pin 1
static constexpr int PUMP_TOGGLE_PIN_2 = 5;  // Toggle switch input pin 2
static constexpr int PUMP_MOSFET_PIN   = 33; // MOSFET gate control pin

// Fan Control
static constexpr int ROTARY_ADC_PIN    = 34; // Rotary encoder analog input pin
static constexpr int FAN_OUTPUT_PWM_1  = 27; // PWM output pin for fan 1
static constexpr int FAN_OUTPUT_PWM_2  = 13; // PWM output pin for fan 2
static constexpr int TACH_PIN1         = 25; // Fan 1 Tach pin
static constexpr int TACH_PIN2         = 39; // Fan 2 Tach pin

// NeoPixel
static constexpr int NEOPIXEL_POWER    = 2;  // NeoPixel power pin (must be HIGH)
static constexpr int NEOPIXEL_PIN      = 0;  // Default pin for onboard NeoPixel

// ------------------- Fan PWM Configuration & Constants -------------------
// Fan Rotary Switch ADC sampling parameters
const int ADC_SAMPLES = 10;

// PWM configuration parameters specifically for fan control
const int FAN_PWM_FREQUENCY = 25000;
const int FAN_PWM_RESOLUTION = 10;
const int FAN_PWM_CHANNEL_1 = 0;
const int FAN_PWM_CHANNEL_2 = 1;

// Fan RPM calculation interval (milliseconds)
const unsigned long RPM_CALC_INTERVAL = 1000;

// Fan ramping parameters
const unsigned long RAMP_STEP_INTERVAL = 9;
const int RAMP_STEP_SIZE = 25;

// ------------------- LED PWM Configuration -------------------
static constexpr int LED_PWM_CHANNEL    = 3;
static constexpr int LED_PWM_FREQUENCY  = 18000;
static constexpr int LED_PWM_RESOLUTION = 10;

// ------------------- PUMP PWM Configuration -------------------
// LEDC configuration parameters for pump
static constexpr int PUMP_LEDC_CHANNEL  = 2;    // Use channel 2 for the pump
static constexpr int PUMP_LEDC_FREQUENCY = 5000; // 5kHz frequency - typical for pumps
static constexpr int PUMP_LEDC_RESOLUTION = 8;   // 8-bit resolution (0-255)

// ------------------- NEOPIXEL Configuration -------------------
// Water level constants (in mm)
static constexpr int WATER_FULL  = 150;      // 150 mm = 100% full
static constexpr int WATER_EMPTY = 615;      // 615 mm = 0% empty
static constexpr int WATER_RANGE = WATER_EMPTY - WATER_FULL;

// NeoPixel colors (RGB format)
static constexpr uint32_t COLOR_RED    = 0xFF0000;
static constexpr uint32_t COLOR_GREEN  = 0x00FF00;
static constexpr uint32_t COLOR_BLUE   = 0x0000FF;
static constexpr uint32_t COLOR_YELLOW = 0xFFFF00;
static constexpr uint32_t COLOR_WHITE  = 0xFFFFFF;

// NeoPixel water level indication thresholds (percentages)
static constexpr float INDICATE_GREEN_PERCENT = 95.0f;
static constexpr float INDICATE_YELLOW_PERCENT = 20.0f;

// ------------------- Default Schedule Parameters -------------------
static constexpr int DEFAULT_FAN_DURATION = 30;   // minutes per hour
static constexpr int DEFAULT_FAN_AUTOSPEED = 2;   // 1=Very Low, 2=Low, 3=Medium, 4=High

// LED grow light schedule defaults
static constexpr int DEFAULT_LED_START_HOUR = 9;  // 9 AM
static constexpr int DEFAULT_LED_STOP_HOUR  = 21; // 9 PM

// Pump schedule defaults
static constexpr int DEFAULT_PUMP_TIME     = 8; // 8 AM - pump turns on at this hour
static constexpr int DEFAULT_PUMP_DURATION = 1; // Run for N minutes

// Water Level Sensor
static constexpr int WATER_SENSOR_ADDR = 0x74; // Corrected I2C address for DFRobot sensor

// ------------------- WiFi Buffer Sizes -------------------
// Fixed buffer sizes to prevent heap fragmentation
static constexpr int WIFI_SSID_MAX_LEN = 64;
static constexpr int WIFI_PASSWORD_MAX_LEN = 64;
static constexpr int JSON_BUFFER_SIZE = 512;
static constexpr int NETWORK_JSON_BUFFER_SIZE = 1024;
static constexpr int TIME_STRING_SIZE = 9;  // HH:MM:SS + null
static constexpr int TEMP_BUFFER_SIZE = 32;  // For temporary string operations
static constexpr int COMMAND_BUFFER_SIZE = 256;  // Back to original size
static constexpr int VALUE_BUFFER_SIZE = 32;     // For extracted values
static constexpr int SETUP_FORM_BUFFER_SIZE = 64; // For form data processing

// NASA Power of 10 Rule #3: Constants for static memory allocation
static constexpr int MAX_IO_OBJECTS = 1;      // Maximum number of IO objects used
static constexpr int MAX_FEED_OBJECTS = 2;    // Maximum number of Feed objects used

// Adafruit IO credentials
#define IO_USERNAME "ecologic"
#define IO_KEY "aio_otvh897kyJI69uEnBIMFQjNaNjPf"

// WiFi Setup AP credentials
#define SETUP_AP_NAME "BIOM-Setup"
#define SETUP_AP_PASSWORD "biofilter"

// ---------- Relay Module ------------
static constexpr int MAC_ADDR_LEN =6;
constexpr uint8_t DEFAULT_PEER_MAC[MAC_ADDR_LEN] = { 0x00, 0x6F, 0x28, 0xAA, 0xBB, 0xCC };

// ----------- Sensor Module ----------
// add vars --> oled screen dimensions, sens66 address, static char/int 


#endif // PARAMETERS_H
