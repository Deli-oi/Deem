#ifndef FAN_CONTROL_H
#define FAN_CONTROL_H

#include <Arduino.h>
#include "parameters.h"
#include "rtc_handler.h"


// (Defaults provided in parameters.h: DEFAULT_FAN_DURATION, DEFAULT_FAN_AUTOSPEED)

class FanController {
  public:
    FanController(int mosfet1Pin, int mosfet2Pin, int tach1Pin, int tach2Pin, int rotPin, RTCHandler& rtcHandler);
    void begin();            // Initialize PWM, interrupts, and rotary
    void update();           // Read rotary, apply mode/ramping logic
    void readRPM();          // Compute RPM from tach counts

    // Accessors
    const char* mode() const;
    int speed1() const;
    int speed2() const;
    bool scheduleActive() const;
    int rpm1() const;
    int rpm2() const;
    void setWebFanOverride(const char* override);
    void setFanDuration(int duration);
    int getFanDuration() const;
    void setFanAutoSpeed(int speed);
    int getFanAutoSpeed() const;
    void loadSettings();
    void saveSettings();

  private:
    // Hardware pins
    int mosfet1Pin_, mosfet2Pin_, tach1Pin_, tach2Pin_, rotaryPin_;

    // State variables
    char fanMode_[10];
    char webFanOverride_[10];
    int fan1Speed_, fan2Speed_;
    bool fanScheduleActive_;
    int fan1RPM_, fan2RPM_;

    // Tachometer counts
    volatile unsigned long fan1PulseCount_, fan2PulseCount_;
    unsigned long lastRPMUpdateTime_;

    // Ramping state
    struct FanState { int targetDuty, currentDuty; unsigned long lastUpdate; };
    FanState fan1State_, fan2State_;
    int lastRotaryPosition_;

    // Helpers
    int smoothADCRead(int pin);
    int getPositionFromADC(int v);
    int handleRotaryPositionChange(int rotPin);
    bool determineScheduleActive();
    void applyModeSettings(int pos, bool shouldRun);
    void applyWebOverride(bool shouldRun);
    void rampFan(FanState &st, int channel);

    RTCHandler& rtcHandler_;
    int fanDuration_ = DEFAULT_FAN_DURATION;
    int fanAutoSpeed_ = DEFAULT_FAN_AUTOSPEED;
};

// Global instance (use in main.cpp and wifi_app.cpp)
extern FanController fanCtl;

#endif // FAN_CONTROL_H
