#include "Arduino.h"
#include "wifi_app.h"
#include "iaq_sensors.h"
#include "rtc_handler.h"
#include <RTClib.h>
#include "water_level.h"
#include "led_control.h"
#include "pump_control.h"
#include "fan_control.h"
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include "parameters.h"
#include <ArduinoJson.h>
#include "globals.h"
#include <esp_heap_caps.h>
#include <PubSubClient.h>

// Constructor
Wifi::Wifi() : server_(80), isInSetupMode_(false), 
               pendingCommandsFlag_(false), lastCommandPoll_(0),
               mqttClient_(wifiClient_), mqttConnected_(false), lastMqttAttempt_(0) {
    memset(pendingCommandsBuf_, 0, sizeof(pendingCommandsBuf_));
    
    // Set up MQTT topics (will be configured in initializeMQTT)
    dataTopicName_ = "";
    commandTopicName_ = "";
}

// Destructor
Wifi::~Wifi() {
    if (mqttClient_.connected()) {
        mqttClient_.disconnect();
    }
}

void Wifi::begin() {
    initWiFi();
}

void Wifi::update() {
    runIO();
}

bool Wifi::getIsInSetupMode() const {
    return isInSetupMode_;
}

// HTML content for setup page
const char SETUP_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BIOM WiFi Setup</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
      color: #333;
    }
    .container {
      max-width: 400px;
      margin: 0 auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: #235c23;
    }
    form {
      display: flex;
      flex-direction: column;
    }
    label {
      margin-top: 15px;
      margin-bottom: 5px;
      font-weight: bold;
    }
    input[type="text"], input[type="password"] {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 16px;
    }
    input[type="submit"] {
      margin-top: 25px;
      padding: 12px;
      background-color: #235c23;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 16px;
      cursor: pointer;
      font-weight: bold;
    }
    .networks {
      margin-top: 20px;
      border-top: 1px solid #ddd;
      padding-top: 15px;
    }
    .network-item {
      padding: 8px 0;
      border-bottom: 1px solid #eee;
      cursor: pointer;
    }
    .network-item:hover {
      background-color: #f5f5f5;
    }
    .success, .error {
      margin: 15px 0;
      padding: 10px;
      border-radius: 4px;
      text-align: center;
    }
    .success {
      background-color: #d4edda;
      color: #155724;
    }
    .error {
      background-color: #f8d7da;
      color: #721c24;
    }
    .manual-url {
      text-align: center;
      margin-top: 20px;
      padding: 10px;
      background-color: #f8f9fa;
      border-radius: 4px;
      font-size: 0.9em;
    }
    .manual-url a {
      font-weight: bold;
      color: #235c23;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>BIOM WiFi Setup</h1>
    <p>Please enter your WiFi network details below:</p>
    
    <form action="/save" method="POST">
      <label for="ssid">WiFi Name (SSID):</label>
      <input type="text" id="ssid" name="ssid" required>
      
      <label for="password">Password:</label>
      <input type="password" id="password" name="password">
      
      <input type="submit" value="Connect">
    </form>
    
    <div class="networks">
      <p>Available Networks:</p>
      <div id="network-list">
        <!-- Networks will be listed here -->
        Scanning...
      </div>
    </div>
    
    <div class="manual-url">
      If this page didn't open automatically, you can access it at:<br>
      <a href="http://setup.biom.bio">setup.biom.bio</a> or <a href="http://192.168.4.1">192.168.4.1</a>
    </div>
  </div>
  
  <script>
    // Auto-fill SSID when clicking on a network name
    function selectNetwork(ssid) {
      document.getElementById('ssid').value = ssid;
    }
    
    // Refresh the network list
    function refreshNetworks() {
      fetch('/scan')
        .then(response => response.json())
        .then(data => {
          let networkListHTML = '';
          data.forEach(network => {
            networkListHTML += `<div class="network-item" onclick="selectNetwork('${network.ssid}')">${network.ssid} (${network.rssi}dBm)</div>`;
          });
          document.getElementById('network-list').innerHTML = networkListHTML || 'No networks found';
        })
        .catch(error => {
          console.error('Error fetching networks:', error);
          document.getElementById('network-list').innerHTML = 'Error fetching networks';
        });
    }
    
    // Initial scan
    setTimeout(refreshNetworks, 1000);
  </script>
</body>
</html>
)rawliteral";

// Success page
const char SUCCESS_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BIOM WiFi Setup</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
      color: #333;
      text-align: center;
    }
    .container {
      max-width: 400px;
      margin: 0 auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    h1 {
      color: #235c23;
    }
    .success {
      margin: 20px 0;
      padding: 15px;
      background-color: #d4edda;
      border-radius: 4px;
      color: #155724;
    }
    p {
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>WiFi Configuration Saved</h1>
    <div class="success">
      The BIOM device is now connecting to your WiFi network.
    </div>
    <p>Please reconnect to your normal WiFi network.</p>
    <p>The device will automatically restart if the connection is successful.</p>
    <p>If the connection fails, the device will return to setup mode, and you can try again.</p>
  </div>
</body>
</html>
)rawliteral";

// Function to initialize preferences
void Wifi::initializePreferences() {
    // Rule 5: Assert valid state
    if (prefs_.isKey("wifi-config")) {
        prefs_.end();
    }
    
    // Rule 7: Check return value
    if (!prefs_.begin("wifi-config", false)) {
        Serial.println("ERROR: Failed to initialize Preferences");
        // Mark preferences as invalid
        prefs_.end();
    }
}

// Check if valid WiFi credentials exist
bool Wifi::hasWiFiCredentials() {
    initializePreferences();
    
    // Rule 7: Validate preferences are open
    if (!prefs_.isKey("ssid")) {
        Serial.println("WARNING: Preferences not properly initialized");
        return false;
    }
    
    // Rule 6: Declare at point of use
    String storedSSID = prefs_.getString("ssid", "");
    String storedPassword = prefs_.getString("password", "");
    
    // Rule 5: Assert reasonable SSID length
    if (storedSSID.length() > 32) {
        Serial.println("ERROR: Stored SSID exceeds maximum length");
        return false;
    }
    
    // Store in member variables only if valid
    savedSSID_ = storedSSID;
    savedPassword_ = storedPassword;
    
    Serial.print("Stored SSID: ");
    Serial.println(savedSSID_);
    
    return savedSSID_.length() > 0;
}

// Get stored WiFi SSID
String Wifi::getWiFiSSID() const {
  return savedSSID_;
}

//Get stored WiFi Password
String Wifi::getWiFiPassword() const {
  return savedPassword_;
}

// Try to connect to WiFi with stored credentials
bool Wifi::checkWiFiConnection(int timeout) {
    // Rule 5: Assert valid timeout
    if (timeout <= 0 || timeout > 60000) {
        Serial.println("ERROR: Invalid timeout value");
        return false;
    }
    
    if (savedSSID_.length() == 0) {
        return false; // No SSID saved
    }
    
    // Rule 5: Assert SSID within valid range
    if (savedSSID_.length() > 32) {
        Serial.println("ERROR: SSID too long");
        return false;
    }
    
    Serial.print("Connecting to ");
    Serial.println(savedSSID_);
    
    WiFi.mode(WIFI_STA);
    WiFi.begin(savedSSID_.c_str(), savedPassword_.c_str());
    
    // Rule 6: Declare timing variables at smallest scope
    const unsigned long startTime = millis();
    const int checkInterval = 500;
    const int maxIterations = (timeout / checkInterval) + 1;
    
    // Rule 5: Assert valid iteration count
    if (maxIterations <= 0 || maxIterations > 200) {
        Serial.println("ERROR: Invalid iteration count");
        return false;
    }
    
    for (int i = 0; i < maxIterations; i++) {
        if (WiFi.status() == WL_CONNECTED) {
            Serial.println("");
            Serial.println("WiFi connected");
            Serial.print("IP address: ");
            Serial.println(WiFi.localIP());
            return true;
        }
        
        if (millis() - startTime > timeout) {
            Serial.println("\nConnection timed out");
            return false;
        }
        
        delay(checkInterval);
        Serial.print(".");
    }
    
    Serial.println("\nConnection timed out");
    return false;
}

// Save WiFi credentials to preferences
bool Wifi::saveWiFiCredentials(const char* ssid, const char* password) {
    // Rule 7: Validate all parameters
    if (!ssid || !password) {
        Serial.println("ERROR: NULL SSID or password");
        return false;
    }
    
    // Rule 5: Assert valid SSID length
    size_t ssidLen = strlen(ssid);
    if (ssidLen == 0 || ssidLen > 32) {
        Serial.println("ERROR: Invalid SSID length");
        return false;
    }
    
    // Rule 5: Assert valid password length (WPA2 requirements)
    size_t passLen = strlen(password);
    if (passLen > 0 && (passLen < 8 || passLen > 63)) {
        Serial.println("ERROR: Invalid password length");
        return false;
    }
    
    initializePreferences();
    
    // Rule 7: Check if preferences are valid
    if (!prefs_.isKey("wifi-config")) {
        Serial.println("ERROR: Preferences not properly initialized");
        return false;
    }

    bool ssidSaved = prefs_.putString("ssid", ssid);
    bool passwordSaved = prefs_.putString("password", password);

    // Rule 7: Check return values
    if (!ssidSaved) {
        Serial.println("ERROR: Failed to save SSID");
        return false;
    }
    
    if (!passwordSaved) {
        Serial.println("ERROR: Failed to save password");
        // Try to remove SSID since password save failed
        prefs_.remove("ssid");
        return false;
    }

    Serial.println("Credentials saved");
    savedSSID_ = String(ssid);
    savedPassword_ = String(password);
    return true;
}

// Clear WiFi credentials from NVS
bool Wifi::clearWiFiCredentials() {
    initializePreferences();
    
    // Rule 7: Check if preferences are valid
    if (!prefs_.isKey("wifi-config")) {
        Serial.println("WARNING: Preferences not initialized, nothing to clear");
        return true;  // Consider this success since there's nothing to clear
    }
    
    bool ssidRemoved = prefs_.remove("ssid");
    bool passwordRemoved = prefs_.remove("password");
    
    // Rule 7: Check return values
    bool success = ssidRemoved && passwordRemoved;
    
    if (success) {
        Serial.println("WiFi credentials cleared successfully");
        savedSSID_ = "";
        savedPassword_ = "";
    } else {
        Serial.println("WARNING: Failed to clear some WiFi credentials");
        // Still clear internal state
        savedSSID_ = "";
        savedPassword_ = "";
    }
    
    return success;
}

// Reset device to factory settings and restart
void Wifi::resetToFactorySettings() {
  Serial.println("Resetting to factory settings...");
  
  // Clear WiFi credentials
  clearWiFiCredentials();
  
  // Optionally, clear other settings - access via globals.h
  Preferences prefs;
  prefs.begin("global", false);
  prefs.remove("lightStart");
  prefs.remove("lightStop");
  prefs.remove("pumpTime");
  prefs.remove("pumpDuration");
  prefs.remove("fanDuration");
  prefs.remove("fanSpeed");
  prefs.end();
  
  Serial.println("Factory reset complete. Restarting device...");
  delay(1000);
  
  // Restart the device
  ESP.restart();
}

// Add the debugMQTT implementation for raw MQTT
void Wifi::debugMQTT() {
    Serial.println(F("=== RAW MQTT DEBUG INFO ==="));
    
    Serial.print(F("MQTT Connected: "));
    Serial.println(mqttConnected_ ? "YES" : "NO");
    
    Serial.print(F("MQTT Client State: "));
    int state = mqttClient_.state();
    switch(state) {
        case MQTT_CONNECTION_TIMEOUT:     Serial.println("Connection timeout"); break;
        case MQTT_CONNECTION_LOST:        Serial.println("Connection lost"); break;
        case MQTT_CONNECT_FAILED:         Serial.println("Connect failed"); break;
        case MQTT_DISCONNECTED:           Serial.println("Disconnected"); break;
        case MQTT_CONNECTED:              Serial.println("Connected"); break;
        case MQTT_CONNECT_BAD_PROTOCOL:   Serial.println("Bad protocol"); break;
        case MQTT_CONNECT_BAD_CLIENT_ID:  Serial.println("Bad client ID"); break;
        case MQTT_CONNECT_UNAVAILABLE:    Serial.println("Server unavailable"); break;
        case MQTT_CONNECT_BAD_CREDENTIALS: Serial.println("Bad credentials"); break;
        case MQTT_CONNECT_UNAUTHORIZED:   Serial.println("Unauthorized"); break;
        default: Serial.print("Unknown state: "); Serial.println(state); break;
    }
    
    Serial.print(F("WiFi Status: "));
    Serial.println(WiFi.status() == WL_CONNECTED ? "Connected" : "Disconnected");
    
    Serial.print(F("Data Topic: "));
    Serial.println(dataTopicName_);
    
    Serial.print(F("Command Topic: "));
    Serial.println(commandTopicName_);
    
    Serial.print(F("Free Heap: "));
    Serial.println(ESP.getFreeHeap());
    
    Serial.println(F("==========================="));
}

// Start WiFi Setup Mode
void Wifi::startWiFiSetupMode() {
  isInSetupMode_ = true;

  Serial.println("Starting WiFi Setup Mode");
  
  // Rule 7: Check WiFi mode change
  if (!WiFi.mode(WIFI_AP)) {
    Serial.println("ERROR: Failed to set WiFi AP mode");
    isInSetupMode_ = false;
    return;
  }
  
  // Rule 8: Use const variables instead of macros
  bool apStarted = WiFi.softAP(SETUP_AP_NAME, SETUP_AP_PASSWORD);
  if (!apStarted) {
    Serial.println("ERROR: Failed to start AP mode");
    isInSetupMode_ = false;
    return;
  }

  Serial.print("AP IP address: ");
  Serial.println(WiFi.softAPIP());

  // Rule 5: Assert DNS server start
  bool dnsStarted = dnsServer_.start(53, "*", WiFi.softAPIP());
  if (!dnsStarted) {
    Serial.println("ERROR: Failed to start DNS server");
    WiFi.softAPdisconnect(true);
    isInSetupMode_ = false;
    return;
  }

  // Configure web server routes - simplified without nested lambdas
  setupWebServerRoutes();
  
  server_.begin();
  
  Serial.println("HTTP server started");
  Serial.println("Setup can be accessed at: http://setup.biom.bio or http://192.168.4.1");
}

// New method to setup web server routes with simple control flow
void Wifi::setupWebServerRoutes() {
    // Rule 9: We must use lambdas here temporarily, but they just call our methods
    // This is the minimum required function pointer usage for the WebServer library
    server_.on("/", HTTP_GET, [this]() { handleRootRequest(); });
    server_.on("/hotspot-detect.html", HTTP_GET, [this]() { handleRootRequest(); });
    server_.on("/generate_204", HTTP_GET, [this]() { handleRootRequest(); });
    server_.on("/connecttest.txt", HTTP_GET, [this]() { 
        server_.send(200, "text/plain", "Success"); 
    });
    server_.on("/redirect", HTTP_GET, [this]() { handleRootRequest(); });
    server_.on("/setup.biom.bio", HTTP_GET, [this]() { handleRootRequest(); });
    server_.on("/save", HTTP_POST, [this]() { handleSaveRequest(); });
    server_.on("/scan", HTTP_GET, [this]() { handleScanRequest(); });
    server_.onNotFound([this]() { handleNotFound(); });
}

// Rule 9: Add method to handle incoming HTTP requests without callbacks
void Wifi::handleRootRequest() {
    server_.send(200, "text/html", SETUP_HTML);
}

void Wifi::handleSaveRequest() {
    handleSaveCredentials();
}

void Wifi::handleScanRequest() {
    handleNetworkScan();
}

// New method to handle save credentials with simple control flow
void Wifi::handleSaveCredentials() {
    // Rule 7: Validate server state
    if (!server_.hasArg("ssid") || !server_.hasArg("password")) {
        server_.send(400, "text/plain", "Missing required parameters");
        return;
    }
    
    String ssid = server_.arg("ssid");
    String password = server_.arg("password");
    
    // Rule 5: Assert valid SSID
    if (ssid.length() == 0 || ssid.length() > 32) {
        server_.send(400, "text/plain", "Invalid SSID length");
        return;
    }
    
    // Rule 5: Assert valid password if provided
    if (password.length() > 0 && (password.length() < 8 || password.length() > 63)) {
        server_.send(400, "text/plain", "Invalid password length");
        return;
    }
    
    // Rule 7: Check return value
    if (!saveWiFiCredentials(ssid.c_str(), password.c_str())) {
        server_.send(500, "text/plain", "Failed to save credentials");
        return;
    }
    
    server_.send(200, "text/html", SUCCESS_HTML);
    
    // Give time for the response to be sent
    delay(500);
    
    // Attempt to connect to the WiFi with new credentials
    stopWiFiSetupMode();
}

void Wifi::runIO() {
    // Handle WiFi setup mode if active
    if (isInSetupMode_) {
        dnsServer_.processNextRequest();
        
        // Rule 9: Manual route handling without callbacks
        // The WebServer library handles routing internally when we call handleClient()
        // We set up routes once in setupWebServerRoutes() using temporary lambdas
        // that just call our handler methods
        server_.handleClient();
        return;
    }

    // Check if MQTT client is available
    if (!mqttConnected_) {
        return;
    }

    // Keep MQTT connection alive
    mqttClient_.loop();
    
    // Check MQTT connection status periodically
    checkMQTTStatus();
    
    // Process deferred commands
    processDeferredCommands();
}

// Add the missing initWiFi implementation
void Wifi::initWiFi() {
    // Simple control flow - check credentials first
    bool hasCredentials = hasWiFiCredentials();
    bool connected = false;
    
    if (hasCredentials) {
        connected = checkWiFiConnection(10000);
    }
    
    if (!hasCredentials || !connected) {
        startWiFiSetupMode();
        return;
    }

    // Initialize Raw MQTT
    initializeMQTT();
}

// Raw MQTT implementation to eliminate SSL buffer errors entirely
void Wifi::initializeMQTT() {
    Serial.println(F("Initializing Raw MQTT connection..."));
    
    uint32_t freeHeap = ESP.getFreeHeap();
    Serial.print("Free heap before MQTT setup: ");
    Serial.println(freeHeap);
    
    // Configure MQTT client
    mqttClient_.setServer(MQTT_SERVER, MQTT_PORT);
    mqttClient_.setBufferSize(MQTT_BUFFER_SIZE);
    mqttClient_.setCallback(mqttCallback);
    
    // Set up topic names using Adafruit IO format
    dataTopicName_ = String(IO_USERNAME) + "/feeds/receive_data";
    commandTopicName_ = String(IO_USERNAME) + "/feeds/send_commands";
    
    Serial.print("Data topic: ");
    Serial.println(dataTopicName_);
    Serial.print("Command topic: ");
    Serial.println(commandTopicName_);
    
    // Connect to MQTT broker
    connectToMQTT();
    
    Serial.print("Free heap after MQTT setup: ");
    Serial.println(ESP.getFreeHeap());
}

// Static callback for MQTT messages
void Wifi::mqttCallback(char* topic, byte* payload, unsigned int length) {
    // Forward to instance method
    wifi.handleMqttMessage(topic, (char*)payload);
}

// Handle incoming MQTT messages
void Wifi::handleMqttMessage(const char* topic, const char* message) {
    Serial.print("MQTT message received on topic: ");
    Serial.println(topic);
    Serial.print("Message: ");
    Serial.println(message);
    
    // Check if this is a command message
    String topicStr = String(topic);
    if (topicStr.equals(commandTopicName_)) {
        processCommand(message);
    }
}

// Process incoming commands
void Wifi::processCommand(const char* command) {
    // Store the command for deferred processing
    strncpy(pendingCommandsBuf_, command, sizeof(pendingCommandsBuf_) - 1);
    pendingCommandsBuf_[sizeof(pendingCommandsBuf_) - 1] = '\0';
    pendingCommandsFlag_ = true;
    
    Serial.print("Command queued for processing: ");
    Serial.println(pendingCommandsBuf_);
}

// Connect to MQTT broker
void Wifi::connectToMQTT() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi not connected, cannot connect to MQTT");
        return;
    }
    
    // Generate a unique client ID
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);
    
    Serial.print("Connecting to MQTT broker at ");
    Serial.print(MQTT_SERVER);
    Serial.print(":");
    Serial.println(MQTT_PORT);
    Serial.print("Client ID: ");
    Serial.println(clientId);
    
    // Connect with Adafruit IO credentials
    if (mqttClient_.connect(clientId.c_str(), IO_USERNAME, IO_KEY)) {
        Serial.println("Connected to MQTT broker!");
        mqttConnected_ = true;
        
        // Subscribe to command topic
        Serial.print("Subscribing to: ");
        Serial.println(commandTopicName_);
        
        if (mqttClient_.subscribe(commandTopicName_.c_str())) {
            Serial.println("Successfully subscribed to command topic");
        } else {
            Serial.println("Failed to subscribe to command topic");
        }
    } else {
        Serial.print("Failed to connect to MQTT broker, state: ");
        Serial.println(mqttClient_.state());
        mqttConnected_ = false;
    }
}

// New method to handle network scan with simple control flow
void Wifi::handleNetworkScan() {
    // Rule 3: Use static buffer instead of dynamic String
    const int maxJsonSize = 1024;
    char jsonBuffer[maxJsonSize];
    
    // Rule 5: Assert buffer is valid
    if (maxJsonSize < 100) {
        server_.send(500, "text/plain", "Internal error");
        return;
    }
    
    // Rule 6: Declare jsonLen at smallest scope
    int jsonLen = 0;
    
    // Rule 7: Check return value of snprintf
    int written = snprintf(jsonBuffer + jsonLen, maxJsonSize - jsonLen, "[");
    if (written < 0 || written >= maxJsonSize - jsonLen) {
        server_.send(500, "text/plain", "Buffer error");
        return;
    }
    jsonLen += written;
    
    const int maxNetworks = 20;
    int n = WiFi.scanNetworks();
    
    // Rule 5: Assert scan result is valid
    if (n < 0) {
        Serial.println("ERROR: WiFi scan failed");
        server_.send(500, "text/plain", "Scan failed");
        return;
    }
    
    if (n > maxNetworks) {
        n = maxNetworks;
    }
    
    // Rule 2: Loop has fixed upper bound (maxNetworks)
    for (int i = 0; i < n && i < maxNetworks; ++i) {
        if (i > 0) {
            written = snprintf(jsonBuffer + jsonLen, maxJsonSize - jsonLen, ",");
            if (written < 0 || written >= maxJsonSize - jsonLen) {
                break;
            }
            jsonLen += written;
        }
        
        // Rule 6: Declare SSID and RSSI in loop scope
        String ssid = WiFi.SSID(i);
        int rssi = WiFi.RSSI(i);
        
        // Rule 5: Assert valid RSSI range
        if (rssi > 0 || rssi < -100) {
            rssi = -99; // Cap to reasonable value
        }
        
        // Rule 6: Declare written in smallest scope
        written = snprintf(jsonBuffer + jsonLen, maxJsonSize - jsonLen,
                          "{\"ssid\":\"%s\",\"rssi\":%d}", 
                          ssid.c_str(), rssi);
        
        // Rule 7: Check snprintf return value
        if (written > 0 && jsonLen + written < maxJsonSize) {
            jsonLen += written;
        } else {
            // Buffer full, stop adding networks
            break;
        }
    }
    
    written = snprintf(jsonBuffer + jsonLen, maxJsonSize - jsonLen, "]");
    if (written < 0 || jsonLen + written >= maxJsonSize) {
        server_.send(500, "text/plain", "Buffer overflow");
        return;
    }
    
    server_.send(200, "application/json", jsonBuffer);
}

// New method to handle not found requests with simple control flow
void Wifi::handleNotFound() {
  String host = server_.hostHeader();
  
  if (host == "captive.apple.com" || host == "www.apple.com") {
    server_.sendHeader("Location", "http://setup.biom.bio");
    server_.send(302, "text/plain", "");
    return;
  }
  
  server_.send(200, "text/html", SETUP_HTML);
}

// Stop WiFi Setup Mode and try to connect with saved credentials
void Wifi::stopWiFiSetupMode() {
  if (!isInSetupMode_) return;
  
  server_.stop();
  dnsServer_.stop();
  WiFi.softAPdisconnect(true);
  
  Serial.println("Setup mode stopped, attempting to connect to WiFi");
  
  if (checkWiFiConnection(10000)) {
    isInSetupMode_ = false;
    ESP.restart(); // Restart to apply new configuration
    return;
  }
  
  Serial.println("Failed to connect, returning to setup mode");
  startWiFiSetupMode();
}

// Simplified MQTT status check for raw MQTT
void Wifi::checkMQTTStatus() {
    static unsigned long lastCheck = 0;
    static unsigned long reconnectBackoff = 30000; // Start with 30 seconds
    
    unsigned long now = millis();
    
    // Check every 30 seconds or based on backoff
    if (now - lastCheck < reconnectBackoff) {
        return;
    }
    lastCheck = now;
    
    if (!mqttClient_.connected()) {
        Serial.println(F("MQTT disconnected, attempting reconnect..."));
        
        // Simple exponential backoff
        reconnectBackoff = min(reconnectBackoff * 2, 300000UL); // Max 5 minutes
        
        Serial.print(F("MQTT reconnect backoff: "));
        Serial.print(reconnectBackoff / 1000);
        Serial.println(F(" seconds"));
        
        // Attempt simple reconnection
        mqttConnected_ = false;
        connectToMQTT();
        
        Serial.println(F("MQTT reconnect attempt initiated"));
    } else {
        // Connected successfully, reset backoff
        reconnectBackoff = 30000; // Reset to 30 seconds
        mqttConnected_ = true;
    }
}

// Process deferred commands for raw MQTT
void Wifi::processDeferredCommands() {
    if (!pendingCommandsFlag_) {
        return;
    }
    
    // Process the command directly as a string
    Serial.print("Processing deferred command: ");
    Serial.println(pendingCommandsBuf_);
    
    // Parse JSON command
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, pendingCommandsBuf_);
    
    if (error) {
        Serial.print("Failed to parse command JSON: ");
        Serial.println(error.c_str());
        pendingCommandsFlag_ = false;
        return;
    }
    
    // Process individual commands
    if (doc["led"].is<const char*>()) {
        processLEDCommand(doc["led"]);
    }
    if (doc["pump"].is<const char*>()) {
        processPumpCommand(doc["pump"]);
    }
    if (doc["fan"].is<const char*>()) {
        processFanCommand(doc["fan"]);
    }
    if (doc["lightStart"].is<int>() || doc["l1"].is<int>()) {
        processScheduleCommands(pendingCommandsBuf_);
    }
    if (doc["factoryReset"].is<const char*>()) {
        processFactoryResetCommand(doc["factoryReset"]);
    }
    
    // Clear the flag and buffer
    pendingCommandsFlag_ = false;
    memset(pendingCommandsBuf_, 0, sizeof(pendingCommandsBuf_));
}

// Raw MQTT implementation for saveReceiveData() - no SSL buffer errors!
void Wifi::saveReceiveData() {
    static unsigned long lastPublishAttempt = 0;
    static int consecutiveErrors = 0;
    static unsigned long publishBackoff = 60000; // Start with 1 minute
    
    unsigned long now = millis();
    
    // Check MQTT connection status
    if (!mqttConnected_ || !mqttClient_.connected()) {
        Serial.println(F("ERROR: MQTT not connected"));
        consecutiveErrors++;
        if (consecutiveErrors > 3) {
            // Attempt reconnection
            connectToMQTT();
            publishBackoff = min(60000UL * (1 << consecutiveErrors), 300000UL); // Max 5 minutes
        }
        return;
    }
    
    // Implement publish throttling with backoff
    if (now - lastPublishAttempt < publishBackoff) {
        return;
    }
    
    // Basic heap checking for stability
    uint32_t freeHeap = ESP.getFreeHeap();
    if (freeHeap < 30000) {  // Lower threshold since no SSL overhead
        Serial.print(F("WARNING: Low heap ("));
        Serial.print(freeHeap);
        Serial.println(F(" bytes), delaying publish"));
        publishBackoff = min(publishBackoff * 2, 300000UL); // Max 5 minutes
        lastPublishAttempt = now;
        return;
    }
    
    // Use a compact buffer for CSV format
    char csvBuffer[256];
    memset(csvBuffer, 0, sizeof(csvBuffer));
    
    // Get current time
    DateTime now_time = rtcHandler.getTime();
    
    // Get schedule values from preferences
    int lightStart = 9;
    int lightStop = 21;
    int pumpTime = 8;
    int pumpDuration = 1;
    int fanDuration = fanCtl.getFanDuration();
    int fanSpeed = fanCtl.getFanAutoSpeed();
    
    Preferences prefs;
    if (prefs.begin("global", true)) {
        lightStart = prefs.getInt("lightStart", 9);
        lightStop = prefs.getInt("lightStop", 21);
        pumpTime = prefs.getInt("pumpTime", 8);
        pumpDuration = prefs.getInt("pumpDuration", 1);
        prefs.end();
    }
    
    // Convert modes to numbers for smaller payload
    int ledModeNum = 2; // default auto
    if (strcmp(ledCtl.mode(), "off") == 0) ledModeNum = 0;
    else if (strcmp(ledCtl.mode(), "on") == 0) ledModeNum = 1;
    
    int pumpModeNum = 2; // default auto  
    if (strcmp(pumpCtl.mode(), "off") == 0) pumpModeNum = 0;
    else if (strcmp(pumpCtl.mode(), "on") == 0) pumpModeNum = 1;
    
    int fanModeNum = 4; // default auto
    const char* fanMode = fanCtl.mode();
    if (strcmp(fanMode, "off") == 0) fanModeNum = 0;
    else if (strcmp(fanMode, "low") == 0) fanModeNum = 1;
    else if (strcmp(fanMode, "medium") == 0) fanModeNum = 2;
    else if (strcmp(fanMode, "high") == 0) fanModeNum = 3;
    
    // Build ultra-compact CSV: time,pm25,tvoc,co2,temp,hum,water,ledMode,ledBright,pumpMode,pumpRunning,fanMode,lightStart,lightStop,pumpTime,pumpDuration,fanDuration,fanSpeed,freeHeap,uptime
    int written = snprintf(csvBuffer, sizeof(csvBuffer),
        "%02d:%02d:%02d,%.0f,%d,%d,%.1f,%.0f,%.0f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%lu,%lu",
        now_time.hour(), now_time.minute(), now_time.second(),
        iaqSensors.getPM25(),
        iaqSensors.getTVOC(),
        iaqSensors.getCO2(),
        iaqSensors.getTemperature(),
        iaqSensors.getHumidity(),
        waterLevel.getDistance(),
        ledModeNum,                    // 0=off, 1=on, 2=auto
        ledCtl.getBrightness(),
        pumpModeNum,                   // 0=off, 1=on, 2=auto  
        pumpCtl.isRunning() ? 1 : 0,   // 0/1 instead of true/false
        fanModeNum,                    // 0=off, 1=low, 2=med, 3=high, 4=auto
        lightStart, lightStop, pumpTime, pumpDuration,
        fanDuration, fanSpeed,
        ESP.getFreeHeap(),
        millis() / 1000               // uptime in seconds instead of milliseconds
    );
    
    if (written <= 0 || written >= sizeof(csvBuffer)) {
        Serial.println(F("ERROR: CSV buffer overflow"));
        return;
    }
    
    Serial.print(F("Publishing CSV ("));
    Serial.print(strlen(csvBuffer));
    Serial.print(F(" bytes) via raw MQTT"));
    
    // Attempt publish with error tracking
    lastPublishAttempt = now;
    unsigned long publishStart = millis();
    
    // Direct MQTT publish - no SSL, no buffer issues!
    bool publishSuccess = mqttClient_.publish(dataTopicName_.c_str(), csvBuffer);
    unsigned long publishDuration = millis() - publishStart;
    
    if (!publishSuccess) {
        consecutiveErrors++;
        Serial.print(F("ERROR: Failed to publish MQTT data (attempt "));
        Serial.print(consecutiveErrors);
        Serial.println(F(")"));
        
        // Exponential backoff for errors
        publishBackoff = min(60000UL * (1 << consecutiveErrors), 300000UL); // Max 5 minutes
        Serial.print(F("Next publish attempt in "));
        Serial.print(publishBackoff / 1000);
        Serial.println(F(" seconds"));
        
        // Try to reconnect MQTT on repeated failures
        if (consecutiveErrors > 2) {
            Serial.println(F("Multiple failures - attempting MQTT reconnection"));
            mqttConnected_ = false;
            connectToMQTT();
        }
    } else {
        consecutiveErrors = 0; // Reset on success
        publishBackoff = 60000;   // Reset to base interval
        Serial.print(F("SUCCESS: MQTT data published ("));
        Serial.print(publishDuration);
        Serial.println(F("ms)"));
        
        // Raw MQTT should be much faster than SSL
        if (publishDuration > 5000) {
            Serial.print(F("WARNING: Slow MQTT publish ("));
            Serial.print(publishDuration);
            Serial.println(F("ms) - network issues?"));
        }
    }
}

// Command processing helpers - use the existing method names
void Wifi::processLEDCommand(const char* cmd) {
    if (!cmd) return;
    
    if (strcasecmp(cmd, "on") == 0) {
        ledCtl.setWebLEDOverride("On");
    } else if (strcasecmp(cmd, "off") == 0) {
        ledCtl.setWebLEDOverride("Off");
    } else if (strcasecmp(cmd, "auto") == 0) {
        ledCtl.setWebLEDOverride("Auto");
    }
}

void Wifi::processPumpCommand(const char* cmd) {
    if (!cmd) return;
    
    if (strcasecmp(cmd, "on") == 0) {
        pumpCtl.setMode("on");
    } else if (strcasecmp(cmd, "off") == 0) {
        pumpCtl.setMode("off");
    } else if (strcasecmp(cmd, "auto") == 0) {
        pumpCtl.setMode("auto");
    }
}

void Wifi::processFanCommand(const char* cmd) {
    if (!cmd) return;
    
    // Use the web override method that exists
    fanCtl.setWebFanOverride(cmd);
}

void Wifi::processScheduleCommands(const char* jsonStr) {
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, jsonStr);
    
    if (error) {
        Serial.print(F("ERROR: Failed to parse schedule JSON: "));
        Serial.println(error.c_str());
        return;
    }
    
    // Check for both full and simplified formats
    int lightStart = doc["lightStart"] | doc["l1"] | -1;
    int lightStop = doc["lightStop"] | doc["l2"] | -1;
    int pumpTime = doc["pumpTime"] | doc["p1"] | -1;
    int pumpDuration = doc["pumpDuration"] | doc["p2"] | -1;
    int fanDuration = doc["fanDuration"] | doc["f1"] | -1;
    
    // Handle fanSpeed which might be string or number
    int fanSpeedValue = -1;
    if (doc["fanSpeed"].is<int>()) {
        fanSpeedValue = doc["fanSpeed"];
    } else if (doc["f2"].is<int>()) {
        fanSpeedValue = doc["f2"];
    } else if (doc["fanSpeed"].is<const char*>()) {
        const char* speedStr = doc["fanSpeed"];
        if (strcasecmp(speedStr, "silent") == 0) fanSpeedValue = 0;
        else if (strcasecmp(speedStr, "low") == 0) fanSpeedValue = 1;
        else if (strcasecmp(speedStr, "medium") == 0) fanSpeedValue = 2;
        else if (strcasecmp(speedStr, "high") == 0) fanSpeedValue = 3;
    } else if (doc["f2"].is<const char*>()) {
        const char* speedStr = doc["f2"];
        if (strcasecmp(speedStr, "silent") == 0) fanSpeedValue = 0;
        else if (strcasecmp(speedStr, "low") == 0) fanSpeedValue = 1;
        else if (strcasecmp(speedStr, "medium") == 0) fanSpeedValue = 2;
        else if (strcasecmp(speedStr, "high") == 0) fanSpeedValue = 3;
    }
    
    // Update settings using globals and preferences
    Preferences prefs;
    
    // Use false for read-write mode, and check if it succeeds
    if (!prefs.begin("global", false)) {
        Serial.println(F("ERROR: Failed to open preferences for writing"));
        return;
    }
    
    if (lightStart >= 0 && lightStop >= 0) {
        ledCtl.setSchedule(lightStart, lightStop);
        prefs.putInt("lightStart", lightStart);
        prefs.putInt("lightStop", lightStop);
        Serial.print(F("Light schedule updated: "));
        Serial.print(lightStart); Serial.print(F(" - ")); Serial.println(lightStop);
    }
    
    if (pumpTime >= 0 && pumpDuration >= 0) {
        pumpCtl.setSchedule(pumpTime, pumpDuration);
        prefs.putInt("pumpTime", pumpTime);
        prefs.putInt("pumpDuration", pumpDuration);
        Serial.print(F("Pump schedule updated: "));
        Serial.print(pumpTime); Serial.print(F(" for ")); Serial.print(pumpDuration); Serial.println(F(" min"));
    }
    
    if (fanDuration >= 0) {
        fanCtl.setFanDuration(fanDuration);
        prefs.putInt("fanDuration", fanDuration);
        Serial.print(F("Fan duration updated: ")); Serial.println(fanDuration);
    }
    
    if (fanSpeedValue >= 0) {
        fanCtl.setFanAutoSpeed(fanSpeedValue);
        prefs.putInt("fanSpeed", fanSpeedValue);
        Serial.print(F("Fan speed updated: ")); Serial.println(fanSpeedValue);
    }
    
    prefs.end();
    Serial.println(F("Schedule updated successfully"));
}

// Add the missing processFactoryResetCommand implementation
void Wifi::processFactoryResetCommand(const char* resetType) {
    if (!resetType) return;
    
    if (strcasecmp(resetType, "wifi") == 0) {
        Serial.println(F("Received WiFi reset command"));
        clearWiFiCredentials();
        delay(100);
        ESP.restart();
    } else if (strcasecmp(resetType, "all") == 0) {
        Serial.println(F("Received factory reset command"));
        resetToFactorySettings();
    }
}

bool Wifi::isMQTTConnected() const {
    return mqttConnected_;
}



