#ifndef GLOBALS_H
#define GLOBALS_H

#include "led_control.h"
#include "pump_control.h"
#include "fan_control.h"
#include "rtc_handler.h"
#include "iaq_sensors.h"
#include "water_level.h"
#include "neopixel.h"
#include "wifi_app.h"
#include "parameters.h"
#include "wifi_local.h"

// Pin definitions


// Global instances
extern LEDController ledCtl;
extern PumpController pumpCtl;
extern IAQSensors iaqSensors;
extern RTCHandler rtcHandler;
extern FanController fanCtl;
extern WaterLevel waterLevel;
extern NeoPixel neoPixel;
extern Wifi wifi;
extern Wifi_Local wifi_local;
//add name for new sensors?
#endif // GLOBALS_H
