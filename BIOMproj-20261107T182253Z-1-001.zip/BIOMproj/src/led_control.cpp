#include "led_control.h"
#include "rtc_handler.h"       // for extern RTCHandler
#include "wifi_app.h"          // for saveSendReceive()
#include <cassert>
#include <Preferences.h>
#include "parameters.h"        // Ensure LED PWM constants are accessible
#include <globals.h>

extern RTCHandler rtcHandler;

// Preferences instance
static Preferences ledPrefs;

// Constructor
LEDController::LEDController(int togglePin1, int togglePin2, int mosfetPin)
    : togglePin1_(togglePin1), togglePin2_(togglePin2), mosfetPin_(mosfetPin),
      ledBrightness_(0), lastToggleState1_(-1), lastToggleState2_(-1),
      startHour_(DEFAULT_LED_START_HOUR), stopHour_(DEFAULT_LED_STOP_HOUR) {
    strncpy(ledMode_, "Auto", sizeof(ledMode_));
    strncpy(webLEDOverride_, "", sizeof(webLEDOverride_));
}

void LEDController::begin() {
    // Validate pins
    assert(togglePin1_ >= 0 && togglePin2_ >= 0 && mosfetPin_ >= 0);
    pinMode(togglePin1_, INPUT_PULLDOWN);
    pinMode(togglePin2_, INPUT_PULLDOWN);
    ledcSetup(LED_PWM_CHANNEL, LED_PWM_FREQUENCY, LED_PWM_RESOLUTION);
    ledcAttachPin(mosfetPin_, LED_PWM_CHANNEL);
    ledcWrite(LED_PWM_CHANNEL, 0);
    lastToggleState1_ = digitalRead(togglePin1_);
    lastToggleState2_ = digitalRead(togglePin2_);
}

void LEDController::update() {
    // Read toggle inputs
    int s1 = digitalRead(togglePin1_);
    int s2 = digitalRead(togglePin2_);
    handleToggle(s1, s2);
    int value = computeBrightness();
    driveChannel(value);
}

const char* LEDController::mode() const {
    return ledMode_;
}

int LEDController::getBrightness() const {
    return ledBrightness_;
}

void LEDController::loadSettings() {
    ledPrefs.begin("led", true);
    startHour_ = ledPrefs.getInt("startHour", DEFAULT_LED_START_HOUR);
    stopHour_ = ledPrefs.getInt("stopHour", DEFAULT_LED_STOP_HOUR);
    ledPrefs.end();
}

void LEDController::saveSettings() {
    ledPrefs.begin("led", false);
    ledPrefs.putInt("startHour", startHour_);
    ledPrefs.putInt("stopHour", stopHour_);
    ledPrefs.end();
}

void LEDController::setSchedule(int startHour, int stopHour) {
    // Validate hours
    assert(startHour >= 0 && startHour < 24);
    assert(stopHour >= 0 && stopHour < 24);
    startHour_ = startHour;
    stopHour_ = stopHour;
    saveSettings();
}

int LEDController::getStartHour() const {
    return startHour_;
}

int LEDController::getStopHour() const {
    return stopHour_;
}

void LEDController::setWebLEDOverride(const char* override) {
    if (override) {
        strncpy(webLEDOverride_, override, sizeof(webLEDOverride_) - 1);
        webLEDOverride_[sizeof(webLEDOverride_) - 1] = '\0';
    }
}

// Helper methods
void LEDController::handleToggle(int s1, int s2) {
    assert(s1 == LOW || s1 == HIGH);
    assert(s2 == LOW || s2 == HIGH);
    if (s1 != lastToggleState1_ || s2 != lastToggleState2_) {
        if (s1 == LOW && s2 == HIGH)        strncpy(webLEDOverride_, "On", sizeof(webLEDOverride_));
        else if (s2 == LOW && s1 == HIGH)   strncpy(webLEDOverride_, "Off", sizeof(webLEDOverride_));
        else                                 strncpy(webLEDOverride_, "Auto", sizeof(webLEDOverride_));
        lastToggleState1_ = s1;
        lastToggleState2_ = s2;
    }
}

int LEDController::computeBrightness() {
    assert(startHour_ >= 0 && startHour_ < 24);
    assert(stopHour_ >= 0 && stopHour_ < 24);
    int finalB;
    if (strcmp(webLEDOverride_, "On") == 0) {
        finalB = (1 << LED_PWM_RESOLUTION) - 1;
        strncpy(ledMode_, "On", sizeof(ledMode_));
    } else if (strcmp(webLEDOverride_, "Off") == 0) {
        finalB = 0;
        strncpy(ledMode_, "Off", sizeof(ledMode_));
    } else {
        DateTime now = rtcHandler.getTime();
        int h = now.hour();
        bool inWindow;
        if (startHour_ < stopHour_) {
            inWindow = (h >= startHour_ && h < stopHour_);
        } else if (startHour_ > stopHour_) {
            inWindow = (h >= startHour_ || h < stopHour_);
        } else {
            inWindow = false;
        }
        finalB = inWindow ? ((1 << LED_PWM_RESOLUTION) - 1) : 0;
        strncpy(ledMode_, "Auto", sizeof(ledMode_));
    }
    int maxVal = (1 << LED_PWM_RESOLUTION) - 1;
    assert(finalB >= 0 && finalB <= maxVal);
    return finalB;
}

void LEDController::driveChannel(int value) {
    int maxVal = (1 << LED_PWM_RESOLUTION) - 1;
    assert(value >= 0 && value <= maxVal);
    ledcWrite(LED_PWM_CHANNEL, value);
}

// Define global instance in main.cpp

