//specification file 
//class declaration 

//guarding
#ifndef WIFI_LOCAL_H
#define WIFI_LOCAL_H


//include statements
#include <WiFi.h>
#include <esp_now.h>
#include <parameters.h>

//ssid, pass, and mac adress (subject to change?)


//class
class Wifi_Local {
    public:
    void begin();
    //initializations
    void initWiFi();
    void initESPNow();

    void SetCredentials(const char *ssid, const char *password);
    void sendData(const uint8_t *peer_addr, const uint8_t *data, size_t len);
    void setPeer(const uint8_t *peer_addr);
    bool isConnected() const;
    typedef void (*ReceiveCallback)(const uint8_t *mac, const uint8_t *data, int len);
    void setReceiveCallback(ReceiveCallback cb);
    private:
    static void onReceive(const uint8_t *mac, const uint8_t *incomingData, int len);
    static esp_now_peer_info_t peerInfo;
    static bool wifiConnected;
    static bool peerAdded;
    static ReceiveCallback userReceiveCallback;
};
extern Wifi_Local wifi_local;
#endif