#ifndef NEOPIXEL_H
#define NEOPIXEL_H

#include <Adafruit_NeoPixel.h>
#include "parameters.h"

class NeoPixel {
  public:
    NeoPixel();
    void setup();
    void update();
    float waterLevelPercentage();
  private:
    Adafruit_NeoPixel pixel_;
    unsigned long previousBlinkMillis_ = 0;
    const long blinkInterval_ = 500;
    bool blinkState_ = false;
};

#endif // NEOPIXEL_H