#include "pump_control.h"
#include "rtc_handler.h"
// #include "wifi_app.h" // Include the WifiApp class for web communication
#include <cassert>
#include <Preferences.h>
#include "parameters.h" // Ensure PUMP constants are accessible
#include <globals.h>

extern RTCHandler rtcHandler;

// Preferences instance for storing pump settings
static Preferences pumpPrefs;

// Implement PumpController methods
PumpController::PumpController(int togglePin1, int togglePin2, int mosfetPin)
    : togglePin1_(togglePin1)
    , togglePin2_(togglePin2)
    , mosfetPin_(mosfetPin)
    , pumpRunning_(false)
    , pumpScheduleActive_(false)
    , lastToggleState1_(LOW)
    , lastToggleState2_(LOW)
    , scheduleTime_(DEFAULT_PUMP_TIME)
    , scheduleDuration_(DEFAULT_PUMP_DURATION)
{
    strncpy(pumpMode_, "Auto", sizeof(pumpMode_));
    webPumpOverride_[0] = '\0';
}

void PumpController::begin() {
    assert(togglePin1_ >= 0);
    assert(togglePin2_ >= 0);
    assert(mosfetPin_ >= 0);
    pinMode(togglePin1_, INPUT_PULLDOWN);
    pinMode(togglePin2_, INPUT_PULLDOWN);
    ledcSetup(PUMP_LEDC_CHANNEL, PUMP_LEDC_FREQUENCY, PUMP_LEDC_RESOLUTION);
    ledcAttachPin(mosfetPin_, PUMP_LEDC_CHANNEL);
    ledcWrite(PUMP_LEDC_CHANNEL, 0);
    pumpRunning_ = false;
    lastToggleState1_ = digitalRead(togglePin1_);
    lastToggleState2_ = digitalRead(togglePin2_);
}

void PumpController::update() {
    assert(togglePin1_ >= 0);
    assert(togglePin2_ >= 0);
    assert(mosfetPin_ >= 0);
    int s1 = digitalRead(togglePin1_);
    int s2 = digitalRead(togglePin2_);
    assert(s1 == LOW || s1 == HIGH);
    assert(s2 == LOW || s2 == HIGH);
    bool scheduledOn = computeScheduledOn();
    pumpScheduleActive_ = scheduledOn;
    handleToggle(s1, s2);
    int power = computePower(s1, s2, scheduledOn);
    drivePump(power);
}

const char* PumpController::mode() const {
    return pumpMode_;
}

bool PumpController::isRunning() const {
    return pumpRunning_;
}

bool PumpController::isScheduleActive() const {
    return pumpScheduleActive_;
}

// Private helper implementations
bool PumpController::computeScheduledOn() const {
    DateTime now = rtcHandler.getTime();
    return (now.hour() == scheduleTime_ && now.minute() < scheduleDuration_);
}

// Schedule configuration
void PumpController::setSchedule(int timeHour, int durationMinutes) {
    assert(timeHour >= 0 && timeHour < 24);
    assert(durationMinutes >= 0 && durationMinutes <= 60);
    scheduleTime_ = timeHour;
    scheduleDuration_ = durationMinutes;
    saveSettings();
}

int PumpController::getScheduleTime() const {
    return scheduleTime_;
}

int PumpController::getScheduleDuration() const {
    return scheduleDuration_;
}

void PumpController::handleToggle(int s1, int s2) {
    assert(s1 == LOW || s1 == HIGH);
    assert(s2 == LOW || s2 == HIGH);
    if (s1 != lastToggleState1_ || s2 != lastToggleState2_) {
        webPumpOverride_[0] = '\0';
        lastToggleState1_ = s1;
        lastToggleState2_ = s2;
    }
}

int PumpController::computePower(int s1, int s2, bool scheduledOn) {
    assert(s1 == LOW || s1 == HIGH);
    assert(s2 == LOW || s2 == HIGH);
    assert(strlen(webPumpOverride_) < sizeof(webPumpOverride_));
    int power = 0;
    if (strcmp(webPumpOverride_, "") == 0) {
        if (s1 == LOW && s2 == HIGH) {
            power = 255; strncpy(pumpMode_, "On", sizeof(pumpMode_));
        } else if (s2 == LOW && s1 == HIGH) {
            power = 0;   strncpy(pumpMode_, "Off", sizeof(pumpMode_));
        } else {
            power = scheduledOn ? 255 : 0; strncpy(pumpMode_, "Auto", sizeof(pumpMode_));
        }
    } else {
        if (strcmp(webPumpOverride_, "On") == 0) {
            power = 255; strncpy(pumpMode_, "On", sizeof(pumpMode_));
        } else if (strcmp(webPumpOverride_, "Off") == 0) {
            power = 0;   strncpy(pumpMode_, "Off", sizeof(pumpMode_));
        } else {
            power = scheduledOn ? 255 : 0; strncpy(pumpMode_, "Auto", sizeof(pumpMode_));
        }
    }
    assert(power >= 0 && power <= 255);
    return power;
}

void PumpController::drivePump(int power) {
    assert(power >= 0 && power <= 255);
    ledcWrite(PUMP_LEDC_CHANNEL, power);
    pumpRunning_ = (power > 0);
}

void PumpController::setWebPumpOverride(const char* override) {
    strncpy(webPumpOverride_, override, sizeof(webPumpOverride_));
}

void PumpController::setScheduleTime(int time) {
    scheduleTime_ = time;
    saveSettings();
}

void PumpController::setScheduleDuration(int duration) {
    scheduleDuration_ = duration;
    saveSettings();
}

void PumpController::setMode(const char* newMode) {
    if (strcmp(newMode, "on") == 0) {
        strcpy(pumpMode_, "on");
        saveSettings();
    } else if (strcmp(newMode, "off") == 0) {
        strcpy(pumpMode_, "off");
        saveSettings();
    } else if (strcmp(newMode, "auto") == 0) {
        strcpy(pumpMode_, "auto");
        saveSettings();
    }
}

void PumpController::loadSettings() {
    pumpPrefs.begin("pump", true);
    scheduleTime_ = pumpPrefs.getInt("time", DEFAULT_PUMP_TIME);
    scheduleDuration_ = pumpPrefs.getInt("duration", DEFAULT_PUMP_DURATION);
    pumpPrefs.end();
}

void PumpController::saveSettings() {
    pumpPrefs.begin("pump", false);
    pumpPrefs.putInt("time", scheduleTime_);
    pumpPrefs.putInt("duration", scheduleDuration_);
    pumpPrefs.end();
}

