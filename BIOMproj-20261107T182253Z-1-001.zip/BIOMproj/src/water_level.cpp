#include "water_level.h"
#include <Wire.h>
#include "parameters.h"

// WaterLevel class implementation
WaterLevel::WaterLevel() : distance_(0), updateState_(IDLE), stateStartTime_(0), lastUpdateTime_(0) {}

// Helper function to read registers
size_t WaterLevel::readReg(uint8_t reg, uint8_t* pBuf, size_t size) {
    if (pBuf == NULL) {
        return 0;
    }
    Wire.beginTransmission(WATER_SENSOR_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return 0;
    }
    delay(20);  // Important delay from sample code
    
    // Handle the data in chunks if needed
    size_t bytesRead = 0;
    while (bytesRead < size) {
        // Calculate remaining bytes to read
        size_t bytesToRead = size - bytesRead;
        // Limit to 32 bytes per transaction (common I2C buffer size)
        if (bytesToRead > 32) bytesToRead = 32;
        
        // Request a chunk of data
        Wire.requestFrom(WATER_SENSOR_ADDR, bytesToRead);
        
        // Read available bytes into buffer
        size_t i = 0;
        while (Wire.available() && i < bytesToRead) {
            pBuf[bytesRead + i] = Wire.read();
            i++;
        }
        
        // If we didn't get all the bytes we requested, something's wrong
        if (i < bytesToRead) {
            return bytesRead + i;
        }
        
        bytesRead += bytesToRead;
    }
    
    return bytesRead;
}

bool WaterLevel::readRegNonblocking(uint8_t reg, uint8_t* pBuf, size_t size) {
    if (pBuf == NULL) {
        return false;
    }
    Wire.beginTransmission(WATER_SENSOR_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return false;
    }
    
    // Request data without blocking delay
    Wire.requestFrom(WATER_SENSOR_ADDR, size);
    
    // Read available bytes
    size_t bytesRead = 0;
    while (Wire.available() && bytesRead < size) {
        pBuf[bytesRead++] = Wire.read();
    }
    
    return (bytesRead == size); // Return true if we got all bytes
}

bool WaterLevel::writeReg(uint8_t reg, const uint8_t* pBuf, size_t size) {
    if (pBuf == NULL) {
        return false;
    }
    Wire.beginTransmission(WATER_SENSOR_ADDR);
    Wire.write(reg);
    for (size_t i = 0; i < size; i++) {
        Wire.write(pBuf[i]);
    }
    return (Wire.endTransmission() == 0);
}

void WaterLevel::setup() {
    // Check if the sensor is present on the I²C bus
    Wire.beginTransmission(WATER_SENSOR_ADDR);
    if (Wire.endTransmission() != 0) {
        Serial.println("Water level sensor not found!");
    } else {
        Serial.println("Water level sensor initialized.");
        // Do an initial blocking read to get a baseline
        this->update();
    }
}

void WaterLevel::updateNonblocking() {
    // Static buffer for reading data - persists across calls
    static uint8_t buf[2] = {0, 0};
    
    // Only attempt update at the specified interval
    unsigned long currentTime = millis();
    if (updateState_ == IDLE && (currentTime - lastUpdateTime_ < UPDATE_INTERVAL)) {
        return; // Not time for an update yet
    }
    
    switch (updateState_) {
        case IDLE: {
            // Trigger measurement
            uint8_t triggerCmd = 0xB0;
            if (!writeReg(0x10, &triggerCmd, 1)) {
                Serial.println("Error triggering water measurement");
                return;
            }
            
            updateState_ = TRIGGER_SENT;
            stateStartTime_ = currentTime;
            lastUpdateTime_ = currentTime;
            break;
        }
        
        case TRIGGER_SENT: {
            // Wait 50ms after trigger (as per working code)
            if (currentTime - stateStartTime_ >= 50) {
                updateState_ = WAITING_FOR_DATA;
            }
            break;
        }
        
        case WAITING_FOR_DATA: {
            // Try to read the data
            if (readRegNonblocking(0x02, buf, 2)) {
                // Process data using the exact calculation from working code
                int distance = buf[0] * 256 + buf[1] + 10;
                distance_ = static_cast<float>(distance);
                
                // Reset to idle for next reading
                updateState_ = IDLE;
            } else {
                // If read failed, retry a few times before giving up
                static int retryCount = 0;
                retryCount++;
                if (retryCount > 5) {
                    Serial.println("Water level: Read failed after retries");
                    updateState_ = IDLE;
                    retryCount = 0;
                }
            }
            break;
        }
    }
}

void WaterLevel::update() {
    // Use the exact same trigger command as the sample: 0xB0
    uint8_t triggerCmd = 0xB0;
    if (!writeReg(0x10, &triggerCmd, 1)) {
        Serial.println("Water sensor write failed");
        return;
    }
    
    // Important: delay after trigger command
    delay(50);
    
    uint8_t buf[2] = {0};
    size_t bytesRead = readReg(0x02, buf, 2);
    if (bytesRead == 2) {
        // Calculate distance exactly as in the sample code
        int distance = buf[0] * 0x100 + buf[1] + 10;
        this->distance_ = static_cast<float>(distance);
    } else {
        Serial.println("Water sensor read failed");
    }
}

float WaterLevel::getDistance() const {
    return this->distance_;
}
