#ifndef PUMP_CONTROL_H
#define PUMP_CONTROL_H

#include <Arduino.h>
#include "parameters.h"
#include <RTClib.h>

class PumpController {
public:
    PumpController(int togglePin1, int togglePin2, int mosfetPin);
    void begin();
    void update();

    // Schedule configuration
    void setSchedule(int timeHour, int durationMinutes);
    int getScheduleTime() const;
    int getScheduleDuration() const;

    void setWebPumpOverride(const char* override);
    void setScheduleTime(int time);
    void setScheduleDuration(int duration);

    const char* mode() const;
    void setMode(const char* newMode);  // Add this method
    bool isRunning() const;
    bool isScheduleActive() const;

    void loadSettings();
    void saveSettings();

private:
    int togglePin1_;
    int togglePin2_;
    int mosfetPin_;
    char pumpMode_[10];
    bool pumpRunning_;
    bool pumpScheduleActive_;
    char webPumpOverride_[10];
    int lastToggleState1_;
    int lastToggleState2_;
    // Schedule parameters
    int scheduleTime_;
    int scheduleDuration_;  // in minutes

    // Helpers
    bool computeScheduledOn() const;
    void handleToggle(int s1, int s2);
    int computePower(int s1, int s2, bool scheduledOn);
    void drivePump(int power);
};

extern PumpController pumpCtl;

#endif // PUMP_CONTROL_H