#include "iaq_sensors.h"
#include <Wire.h>
#include <math.h>
#include <assert.h>
#include <globals.h>



// Backward compatibility global variables
uint16_t iaq_tvoc = 0;
uint16_t iaq_eco2 = 0;
PM25_AQI_Data iaq_pmData;
uint16_t iaq_co2 = 0;
float iaq_temp = 0.0;
float iaq_humidity = 0.0;

// Constructor
IAQSensors::IAQSensors() 
    : tvoc_(0), eco2_(0), co2_(0), temperature_(0.0), humidity_(0.0),
      sgpAvailable_(false), pm25Available_(false), scd4xAvailable_(false),
      tvocBase_(0), eco2Base_(0), baselineCounter_(0),
      lastSCD4xUpdate_(0), lastUpdate_(0), lastNonblockingUpdate_(0),
      updateInProgress_(false) {
    memset(&pmData_, 0, sizeof(pmData_));
}

// Helper: Compute absolute humidity in mg/m^3 from temperature and RH
uint32_t IAQSensors::getAbsoluteHumidity(float temperature, float humidity) {
    // Validate input parameters
    assert(temperature >= -40.0f && temperature <= 85.0f);
    assert(humidity >= 0.0f && humidity <= 100.0f);
    
    const float absoluteHumidity = 216.7f * ((humidity / 100.0f) * 6.112f *
        exp((17.62f * temperature) / (243.12f + temperature)) / (273.15f + temperature));
    
    const uint32_t result = (uint32_t)(1000.0f * absoluteHumidity);
    assert(result < 100000);
    
    return result;
}

void IAQSensors::begin() {
    Serial.println("Initializing IAQ sensors...");
    const uint16_t MAX_RETRY_COUNT = 3;
    uint16_t retryCount = 0;

    // SGP30 Setup
    Serial.println("Initializing SGP30 sensor...");
    sgpAvailable_ = false;
    retryCount = 0;
    while (!sgpAvailable_ && retryCount < MAX_RETRY_COUNT) {
        sgpAvailable_ = sgp_.begin();
        retryCount++;
        if (!sgpAvailable_ && retryCount < MAX_RETRY_COUNT) {
            delay(100);
        }
    }
    
    if (!sgpAvailable_) {
        Serial.println("SGP30 sensor not found! Skipping SGP30 measurements.");
    } else {
        Serial.print("Found SGP30 serial #");
        Serial.print(sgp_.serialnumber[0], HEX);
        Serial.print(sgp_.serialnumber[1], HEX);
        Serial.println(sgp_.serialnumber[2], HEX);
    }

    // PM2.5 Setup
    Serial.println("Initializing PM2.5 sensor...");
    pm25Available_ = false;
    retryCount = 0;
    while (!pm25Available_ && retryCount < MAX_RETRY_COUNT) {
        pm25Available_ = aqi_.begin_I2C();
        retryCount++;
        if (!pm25Available_ && retryCount < MAX_RETRY_COUNT) {
            delay(100);
        }
    }
    
    if (!pm25Available_) {
        Serial.println("PM2.5 sensor not found! Skipping PM2.5 measurements.");
    } else {
        Serial.println("PM2.5 sensor initialized!");
    }

    // SCD4x Setup
    uint16_t error;
    scd4xAvailable_ = true;
    char errorMessage[256] = {0};
    
    scd4x_.begin(Wire, 0x62);
    error = scd4x_.stopPeriodicMeasurement();
    if (error) {
        errorToString(error, errorMessage, sizeof(errorMessage));
        Serial.print("Error stopping previous SCD4x measurement: ");
        Serial.println(errorMessage);
    }
    
    uint64_t serialNumber;
    error = scd4x_.getSerialNumber(serialNumber);
    if (error) {
        errorToString(error, errorMessage, sizeof(errorMessage));
        Serial.print("Error getting SCD4x serial number: ");
        Serial.println(errorMessage);
        scd4xAvailable_ = false;
    } else {
        Serial.print("SCD4x Serial: 0x");
        Serial.println(serialNumber, HEX);
    }
    
    error = scd4x_.startPeriodicMeasurement();
    if (error) {
        errorToString(error, errorMessage, sizeof(errorMessage));
        Serial.print("Error starting SCD4x periodic measurement: ");
        Serial.println(errorMessage);
        scd4xAvailable_ = false;
    }
    
    if (scd4xAvailable_) {
        Serial.println("Waiting for first SCD4x measurement... (5 sec)");
    } else {
        Serial.println("SCD4x sensor not available! Skipping SCD4x measurements.");
    }
    
    lastSCD4xUpdate_ = millis();
    lastUpdate_ = millis();
}

void IAQSensors::update() {
    unsigned long currentTime = millis();
    
    if (currentTime - lastUpdate_ < 1000) return;
    lastUpdate_ = currentTime;
    
    assert(sgpAvailable_ == true || sgpAvailable_ == false);
    assert(pm25Available_ == true || pm25Available_ == false);
    assert(scd4xAvailable_ == true || scd4xAvailable_ == false);

    uint16_t error;
    
    // SCD4x Measurement
    if (scd4xAvailable_ && (currentTime - lastSCD4xUpdate_ >= 5000)) {
        lastSCD4xUpdate_ = currentTime;
        uint16_t co2Value = 0;
        float tempValue = 0.0f;
        float humidityValue = 0.0f;
        
        error = scd4x_.readMeasurement(co2Value, tempValue, humidityValue);
        if (error) {
            Serial.print("Error in SCD4x readMeasurement(): ");
            Serial.println(error);
        } else if (co2Value == 0) {
            Serial.println("Invalid SCD4x sample, skipping.");
        } else {
            assert(co2Value > 0 && co2Value < 10000);
            assert(tempValue >= -40.0f && tempValue <= 85.0f);
            assert(humidityValue >= 0.0f && humidityValue <= 100.0f);
            
            co2_ = co2Value;
            temperature_ = tempValue;
            humidity_ = humidityValue;
            
            // Update backward compatibility globals
            iaq_co2 = co2_;
            iaq_temp = temperature_;
            iaq_humidity = humidity_;
        }
    }
    
    // SGP30 Measurement
    if (sgpAvailable_) {
        if (scd4xAvailable_ && humidity_ > 0) {
            assert(temperature_ >= -40.0f && temperature_ <= 85.0f);
            assert(humidity_ >= 0.0f && humidity_ <= 100.0f);
            
            uint32_t absHumidity = getAbsoluteHumidity(temperature_, humidity_);
            sgp_.setHumidity(absHumidity);
        }
        
        bool measureSuccess = sgp_.IAQmeasure();
        if (measureSuccess) {
            assert(sgp_.TVOC >= 0 && sgp_.TVOC <= 60000);
            assert(sgp_.eCO2 >= 0 && sgp_.eCO2 <= 60000);
            
            tvoc_ = sgp_.TVOC;
            eco2_ = sgp_.eCO2;
            
            // Update backward compatibility globals
            iaq_tvoc = tvoc_;
            iaq_eco2 = eco2_;
        } else {
            Serial.println("SGP30 measurement failed");
        }
        
        assert(baselineCounter_ >= 0 && baselineCounter_ < 100);
        baselineCounter_++;
        
        const uint8_t MAX_COUNTER = 30;
        if (baselineCounter_ >= MAX_COUNTER) {
            baselineCounter_ = 0;
            if (sgp_.getIAQBaseline(&eco2Base_, &tvocBase_)) {
                // Baseline updated
            } else {
                Serial.println("Failed to get SGP30 baseline");
            }
        }
    }
    
    // PM2.5 Measurement
    if (pm25Available_) {
        bool readSuccess = aqi_.read(&pmData_);
        if (!readSuccess) {
            Serial.println("PM2.5 sensor read failed");
        } else {
            if (pmData_.pm25_standard < 0 || pmData_.pm25_standard > 1000) {
                Serial.print("PM2.5 value out of range: ");
                Serial.println(pmData_.pm25_standard);
                pmData_.pm25_standard = 0;
            }
            // Update backward compatibility global
            iaq_pmData = pmData_;
        }
    }
}

void IAQSensors::updateSGP30() {
    static unsigned long lastSGPRetry = 0;
    unsigned long now = millis();
    if (!sgpAvailable_ && (now - lastSGPRetry > 60000)) {
        lastSGPRetry = now;
        Serial.println("Retrying SGP30 initialization...");
        if (sgp_.begin()) {
            sgpAvailable_ = true;
            Serial.println("SGP30 reinitialized successfully");
        } else {
            Serial.println("SGP30 reinit failed");
        }
    }
    if (!sgpAvailable_) return;

    bool readSuccess = sgp_.IAQmeasure();
    if (!readSuccess) {
        Serial.println("SGP30 measurement failed, disabling sensor");
        sgpAvailable_ = false;
        return;
    }
    
    if (scd4xAvailable_ && humidity_ > 0) {
        assert(temperature_ >= -40.0f && temperature_ <= 85.0f);
        assert(humidity_ >= 0.0f && humidity_ <= 100.0f);
        
        uint32_t absHumidity = getAbsoluteHumidity(temperature_, humidity_);
        sgp_.setHumidity(absHumidity);
    }
    
    assert(readSuccess || !sgpAvailable_);
    
    if (readSuccess) {
        assert(sgp_.TVOC >= 0 && sgp_.TVOC <= 60000);
        assert(sgp_.eCO2 >= 0 && sgp_.eCO2 <= 60000);
        
        tvoc_ = sgp_.TVOC;
        eco2_ = sgp_.eCO2;
        
        // Update backward compatibility globals
        iaq_tvoc = tvoc_;
        iaq_eco2 = eco2_;
    }
}

void IAQSensors::updatePM25() {
    static unsigned long lastPMRetry = 0;
    unsigned long now = millis();
    if (!pm25Available_ && (now - lastPMRetry > 60000)) {
        lastPMRetry = now;
        Serial.println("Retrying PM2.5 sensor initialization...");
        if (aqi_.begin_I2C()) {
            pm25Available_ = true;
            Serial.println("PM2.5 sensor reinitialized successfully");
        } else {
            Serial.println("PM2.5 sensor reinit failed");
        }
    }
    if (!pm25Available_) return;

    bool readSuccess = aqi_.read(&pmData_);
    if (!readSuccess) {
        Serial.println("PM2.5 reading failed, disabling sensor");
        pm25Available_ = false;
        return;
    }
    
    assert(pmData_.pm25_standard >= 0 && pmData_.pm25_standard <= 1000);
    
    // Update backward compatibility global
    iaq_pmData = pmData_;
}

void IAQSensors::updateSCD4x() {
    static unsigned long lastSCD4xRetry = 0;
    unsigned long now = millis();
    if (!scd4xAvailable_ && (now - lastSCD4xRetry > 60000)) {
        lastSCD4xRetry = now;
        Serial.println("Retrying SCD4x reinitialization...");
        char errorMessage[256] = {0};
        scd4x_.begin(Wire, 0x62);
        uint16_t error = scd4x_.stopPeriodicMeasurement();
        if (error) {
            errorToString(error, errorMessage, sizeof(errorMessage));
            Serial.print("Error stopping previous measurement: ");
            Serial.println(errorMessage);
        }
        error = scd4x_.startPeriodicMeasurement();
        if (error) {
            errorToString(error, errorMessage, sizeof(errorMessage));
            Serial.print("Error starting periodic measurement: ");
            Serial.println(errorMessage);
            Serial.println("SCD4x reinit failed");
        } else {
            scd4xAvailable_ = true;
            Serial.println("SCD4x reinitialized successfully");
        }
    }
    if (!scd4xAvailable_) return;

    bool dataReadyFlag = false;
    uint16_t error = scd4x_.getDataReadyStatus(dataReadyFlag);
    if (error) {
        char errorMessage[256] = {0};
        errorToString(error, errorMessage, sizeof(errorMessage));
        Serial.print("Error getting data ready status: ");
        Serial.println(errorMessage);
        Serial.println("Disabling SCD4x sensor");
        scd4xAvailable_ = false;
        return;
    }

    if (dataReadyFlag) {
        uint16_t co2;
        float temperature;
        float humidity;
        error = scd4x_.readMeasurement(co2, temperature, humidity);
        if (error) {
            char errorMessage[256] = {0};
            errorToString(error, errorMessage, sizeof(errorMessage));
            Serial.print("Error reading measurement: ");
            Serial.println(errorMessage);
            Serial.println("Disabling SCD4x sensor");
            scd4xAvailable_ = false;
            return;
        }
        
        assert(co2 >= 0 && co2 <= 10000);
        assert(temperature >= -40.0f && temperature <= 85.0f);
        assert(humidity >= 0.0f && humidity <= 100.0f);

        co2_ = co2;
        temperature_ = temperature;
        humidity_ = humidity;
        lastSCD4xUpdate_ = now;
        
        // Update backward compatibility globals
        iaq_co2 = co2_;
        iaq_temp = temperature_;
        iaq_humidity = humidity_;
    }
}

void IAQSensors::updateNonblocking() {
    static unsigned long lastUpdate = 0;
    unsigned long currentTime = millis();
    
    if (currentTime - lastUpdate < 5000 && !updateInProgress_) {
        return;
    }
    
    if (!updateInProgress_) {
        lastUpdate = currentTime;
        updateInProgress_ = true;
        
        updateSGP30();
        updatePM25();
        updateSCD4x();
        
        updateInProgress_ = false;
    }
}
