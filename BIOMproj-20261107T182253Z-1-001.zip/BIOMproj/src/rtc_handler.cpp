#include "rtc_handler.h"
#include <Arduino.h>
#include <WiFi.h>
#include <globals.h>

RTCHandler::RTCHandler() {}

bool RTCHandler::begin() {
    // Initialize NTP
    configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
    ntp_initialized = true;

    // Initialize RTC as fallback
    return rtc.begin();
}

// Convert tm struct to DateTime
DateTime RTCHandler::tmToDateTime(struct tm *timeinfo) {
    return DateTime(
        timeinfo->tm_year + 1900,
        timeinfo->tm_mon + 1,
        timeinfo->tm_mday,
        timeinfo->tm_hour,
        timeinfo->tm_min,
        timeinfo->tm_sec
    );
}

// Get time from NTP
DateTime RTCHandler::getTimeFromNTP() {
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo)) {
        Serial.println("Failed to obtain time from NTP");
        return rtc.now(); // Fall back to RTC
    }
    return tmToDateTime(&timeinfo);
}

// Set date and time to current from your PC automatically
void RTCHandler::setTime(const DateTime& dt) {
    rtc.adjust(dt);
}

// Sync RTC with NTP time when Wi-Fi is available
bool RTCHandler::syncWithNTP() {
    unsigned long currentMillis = millis();
    
    // Only attempt to sync periodically
    if (currentMillis - last_sync_attempt < SYNC_INTERVAL) {
        return false;
    }
    
    last_sync_attempt = currentMillis;
    
    // Check if we have Wi-Fi connection
    if (WiFi.status() != WL_CONNECTED) {
        return false;
    }
    
    // Get time from NTP
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo)) {
        Serial.println("Failed to obtain time from NTP for syncing");
        return false;
    }
    
    // Convert to DateTime and set RTC
    DateTime ntp_time = tmToDateTime(&timeinfo);
    rtc.adjust(ntp_time);
    
    Serial.println("RTC synced with NTP time");
    return true;
}

// Returns Time - prioritizes NTP when available
DateTime RTCHandler::getTime() {
    // Try to sync RTC with NTP periodically
    syncWithNTP();
    
    // Try to get time from NTP first if we're online
    if (WiFi.status() == WL_CONNECTED && ntp_initialized) {
        struct tm timeinfo;
        if (getLocalTime(&timeinfo)) {
            return tmToDateTime(&timeinfo);
        }
    }
    
    // Fall back to RTC if NTP is unavailable
    return rtc.now();
}

// Initializes clock
bool RTCHandler::isInitialized() {
    // Check if we can get time from NTP
    if (WiFi.status() == WL_CONNECTED && ntp_initialized) {
        return true;
    }
    
    // Fall back to RTC - just check if it hasn't lost power
    return !rtc.lostPower();
}

// Check if current time is within the specified range
bool RTCHandler::isTimeInRange(uint8_t startHour, uint8_t startMinute, 
                              uint8_t endHour, uint8_t endMinute) {
    DateTime now = getTime();
    
    // Convert all times to minutes for easier comparison
    int currentMinutes = now.hour() * 60 + now.minute();
    int startMinutes = startHour * 60 + startMinute;
    int endMinutes = endHour * 60 + endMinute;
    
    // If end time is less than start time, it spans across midnight
    if (endMinutes < startMinutes) {
        return (currentMinutes >= startMinutes || currentMinutes <= endMinutes);
    } else {
        return (currentMinutes >= startMinutes && currentMinutes <= endMinutes);
    }
}

// Check if today is the specified day of week
bool RTCHandler::isDayOfWeek(uint8_t dayOfWeek) {
    DateTime now = getTime();
    return now.dayOfTheWeek() + 1 == dayOfWeek; // +1 because dayOfTheWeek() is 0-indexed
}

// Simple check if current time is between two specific times
bool RTCHandler::isTimeBetween(uint8_t hour1, uint8_t minute1, 
                             uint8_t hour2, uint8_t minute2) {
    return isTimeInRange(hour1, minute1, hour2, minute2);
}

// Non-blocking delay helper
bool RTCHandler::hasElapsed(unsigned long &lastTime, unsigned long interval) {
    unsigned long currentMillis = millis();
    if (currentMillis - lastTime >= interval) {
        lastTime = currentMillis;
        return true;
    }
    return false;
}