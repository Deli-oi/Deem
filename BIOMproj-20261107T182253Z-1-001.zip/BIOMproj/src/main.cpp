#include "globals.h"
#include "Arduino.h"
#include "Wire.h"
#include "led_control.h"
#include "pump_control.h"
#include "fan_control.h"
#include "rtc_handler.h"
#include <RTClib.h>
#include "iaq_sensors.h"
#include "water_level.h"
#include "wifi_app.h"
#include "neopixel.h"
#include "parameters.h"
#include "globals.h"



bool isInSetupMode = false;

uint8_t buf[4] = {0};

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("BIOM System Starting...");

    // Check available memory and configure SSL accordingly
    uint32_t freeHeap = ESP.getFreeHeap();
    Serial.print("Free heap at startup: ");
    Serial.print(freeHeap);
    Serial.println(" bytes");
    
    // Initialize smaller TLS heap to prevent DRAM overflow
    // Use built-in ESP32 memory management instead of custom allocator
    Serial.println("Using ESP32 built-in SSL memory management");

    // Initialize I2C for sensors
    Wire.begin(14, 32);
    iaqSensors.begin();
    waterLevel.setup();
    Serial.println("Sensors initialized");

    // Initialize actuators
    pinMode(LED_BUILTIN, OUTPUT);
    neoPixel.setup();
    pinMode(NEOPIXEL_POWER, OUTPUT);
    digitalWrite(NEOPIXEL_POWER, HIGH);

    fanCtl.loadSettings();
    fanCtl.begin();
    ledCtl.loadSettings();
    ledCtl.begin();
    pumpCtl.loadSettings();
    pumpCtl.begin();
    Serial.println("Actuators initialized");

    // Initialize RTC
    if (!rtcHandler.begin()) {
        Serial.println("RTC not found!");
    } else {
        DateTime now = DateTime(2025, 1, 1, 0, 0, 0);
        rtcHandler.setTime(now);
        Serial.println("RTC initialized");
    }

    // Initialize WiFi with optimized memory management
    Serial.println("Initializing WiFi...");
    wifi.begin();
    Serial.println("Setup complete");
}

void loop() {
    digitalWrite(LED_BUILTIN, HIGH);

    // Update WiFi and IO
    wifi.update();
    
    // No longer need Adafruit IO with raw MQTT implementation
    isInSetupMode = wifi.getIsInSetupMode();
    
    // Simple publish logic for raw MQTT (no SSL overhead)
    static unsigned long lastPublish = 0;
    static unsigned long publishInterval = 60000; // 1 minute for raw MQTT
    
    if (WiFi.status() == WL_CONNECTED && 
        !isInSetupMode && 
        millis() > 30000 &&  // Wait 30 seconds after boot for system stability
        millis() - lastPublish > publishInterval) {
        
        lastPublish = millis();
        
        // Basic heap checking (much lower threshold without SSL)
        uint32_t heapBefore = ESP.getFreeHeap();
        if (heapBefore < 25000) { // Much lower threshold since no SSL
            Serial.println(F("WARNING: Skipping publish due to low memory"));
            Serial.print(F("Free heap: "));
            Serial.println(heapBefore);
        } else {
            Serial.println(F("Publishing data via raw MQTT..."));
            
            unsigned long publishStart = millis();
            wifi.saveReceiveData();
            unsigned long publishDuration = millis() - publishStart;
            
            // Raw MQTT should be very fast
            if (publishDuration > 3000) {
                Serial.print(F("WARNING: Slow MQTT publish ("));
                Serial.print(publishDuration);
                Serial.println(F("ms) - network issues?"));
            } else {
                Serial.print(F("MQTT publish completed in "));
                Serial.print(publishDuration);
                Serial.println(F("ms"));
            }
        }
    }

    // Basic memory monitoring for system stability
    static unsigned long lastMemCheck = 0;
    if (millis() - lastMemCheck > 60000) { // Check every minute
        lastMemCheck = millis();
        uint32_t freeHeap = ESP.getFreeHeap();
        
        if (freeHeap < 20000) { // Much lower threshold without SSL
            Serial.println("WARNING: Low memory detected");
            Serial.print("Free heap: ");
            Serial.println(freeHeap);
            
            // Basic cleanup for critically low memory
            if (freeHeap < 15000) {
                Serial.println("CRITICAL: Very low memory - system may be unstable");
                // Could implement basic cleanup here if needed
            }
        }
    }

    // Update all subsystems
    ledCtl.update();
    pumpCtl.update();
    fanCtl.update();
    iaqSensors.updateNonblocking();
    waterLevel.updateNonblocking();  // Use non-blocking update
    neoPixel.update();

    // Serial status output
    static unsigned long previousPrintMillis = 0;
    if (millis() - previousPrintMillis >= 3000) {
        previousPrintMillis = millis();
        
        // Update RTC Clock Time and print time
        DateTime now = rtcHandler.getTime();
        Serial.print("Current time: ");
        Serial.print(now.year(), DEC);
        Serial.print('/');
        Serial.print(now.month(), DEC);
        Serial.print('/');
        Serial.print(now.day(), DEC);
        Serial.print(" ");
        Serial.print(now.hour(), DEC);
        Serial.print(':');
        Serial.print(now.minute(), DEC);
        Serial.print(':');
        Serial.println(now.second(), DEC);

        // Print IP address
        Serial.println();
        Serial.print("IP Address: ");
        Serial.println(WiFi.localIP());

        // Print IAQ sensor data
        Serial.println();
        Serial.print("IAQ Sensors: TVOC = ");
        Serial.println(iaqSensors.getTVOC());
        Serial.print("CO2 ppm = ");
        Serial.println(iaqSensors.getCO2());
        Serial.print("PM2.5 = ");
        Serial.print(iaqSensors.getPM25());
        Serial.println(" ug/m3");

        // Print water level sensor data
        Serial.print("Water level distance (mm): ");
        Serial.println(waterLevel.getDistance());

        // Print basic actuator states
        Serial.println();
        Serial.print("Fan Mode: ");
        Serial.println(fanCtl.mode());
        Serial.print("Fan1 Speed: "); Serial.println(fanCtl.speed1());
        Serial.print("Fan2 Speed: "); Serial.println(fanCtl.speed2());
        
        Serial.print("LED Mode: ");
        Serial.println(ledCtl.mode());
        
        Serial.print("Pump Mode: ");
        Serial.println(pumpCtl.mode());

        Serial.print("Flash Chip Size: ");
        Serial.println(ESP.getFlashChipSize());

        // Add WiFi status information
        Serial.print("WiFi Status: ");
        if (wifi.getIsInSetupMode()) {
            Serial.println("Setup Mode Active - Connect to BIOM-Setup network");
        } else if (WiFi.status() == WL_CONNECTED) {
            Serial.print("Connected to ");
            Serial.print(wifi.getWiFiSSID());
            Serial.print(" | IP: ");
            Serial.println(WiFi.localIP());
            
            // Add MQTT connection status
            Serial.print("MQTT Status: ");
            if (wifi.isMQTTConnected()) {
                Serial.println("CONNECTED");
            } else {
                Serial.println("DISCONNECTED");
            }
        } else {
            Serial.println("Disconnected");
        }

        // Report available free heap
        Serial.print("Free heap: ");
        Serial.print(ESP.getFreeHeap());
         Serial.print("   | Uptime: ");
         Serial.print(millis()/1000);
         Serial.println(" s");

        // Remove any vTaskList() calls - they require special FreeRTOS config
        // If you need task info, use ESP-IDF functions instead:
        Serial.print("Free stack: ");
        Serial.println(uxTaskGetStackHighWaterMark(NULL));

        Serial.println("___________________________________________________________");
        Serial.println();
    }  
    
    // Small delay for task switching
    delay(10);
}
