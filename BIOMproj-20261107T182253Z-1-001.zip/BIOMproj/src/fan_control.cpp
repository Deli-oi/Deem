#include "Arduino.h"
#include "fan_control.h"
#include "rtc_handler.h"
#include "parameters.h"  // needed for DEFAULT_FAN_DURATION
#include <assert.h>
#include <Preferences.h>
#include <globals.h>

static Preferences fanPrefs;

FanController::FanController(int m1, int m2, int t1, int t2, int rot, RTCHandler& rtcHandler)
 : mosfet1Pin_(m1), mosfet2Pin_(m2), tach1Pin_(t1), tach2Pin_(t2), rotaryPin_(rot),
   fan1PulseCount_(0), fan2PulseCount_(0), lastRPMUpdateTime_(0), rtcHandler_(rtcHandler)
{
    strncpy(fanMode_, "Auto", sizeof(fanMode_));
    webFanOverride_[0] = '\0';
    fan1Speed_ = fan2Speed_ = 0;
    fanScheduleActive_ = false;
    fan1RPM_ = fan2RPM_ = 0;
    fan1State_ = {0,0,0};
    fan2State_ = {0,0,0};
    lastRotaryPosition_ = -1;
}

void FanController::begin() {
    // PWM setup
    ledcSetup(FAN_PWM_CHANNEL_1, FAN_PWM_FREQUENCY, FAN_PWM_RESOLUTION);
    ledcAttachPin(mosfet1Pin_, FAN_PWM_CHANNEL_1);
    ledcSetup(FAN_PWM_CHANNEL_2, FAN_PWM_FREQUENCY, FAN_PWM_RESOLUTION);
    ledcAttachPin(mosfet2Pin_, FAN_PWM_CHANNEL_2);
    ledcWrite(FAN_PWM_CHANNEL_1, 0);
    ledcWrite(FAN_PWM_CHANNEL_2, 0);

    // Tach interrupts
    pinMode(tach1Pin_, INPUT_PULLUP);
    pinMode(tach2Pin_, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(tach1Pin_), [](){ fanCtl.fan1PulseCount_++; }, FALLING);
    attachInterrupt(digitalPinToInterrupt(tach2Pin_), [](){ fanCtl.fan2PulseCount_++; }, FALLING);

    // Rotary input
    pinMode(rotaryPin_, INPUT_PULLDOWN);
    lastRotaryPosition_ = getPositionFromADC(smoothADCRead(rotaryPin_));
}

void FanController::update() {
    int pos = handleRotaryPositionChange(rotaryPin_);
    if (pos <= 0) return;
    bool run = determineScheduleActive();
    fanScheduleActive_ = run;
    if (strlen(webFanOverride_) == 0) applyModeSettings(pos, run);
    else applyWebOverride(run);
    rampFan(fan1State_, FAN_PWM_CHANNEL_1);
    rampFan(fan2State_, FAN_PWM_CHANNEL_2);
}

void FanController::readRPM() {
    unsigned long now = millis();
    if (now - lastRPMUpdateTime_ < RPM_CALC_INTERVAL) return;
    lastRPMUpdateTime_ = now;
    fan1RPM_ = fan1PulseCount_ * 30;
    fan2RPM_ = fan2PulseCount_ * 30;
    fan1PulseCount_ = fan2PulseCount_ = 0;
}

const char* FanController::mode() const { return fanMode_; }
int FanController::speed1() const     { return fan1Speed_; }
int FanController::speed2() const     { return fan2Speed_; }
bool FanController::scheduleActive() const { return fanScheduleActive_; }
int FanController::rpm1() const       { return fan1RPM_; }
int FanController::rpm2() const       { return fan2RPM_; }
int FanController::getFanDuration() const { return fanDuration_; }
void FanController::setFanDuration(int duration) {
    fanDuration_ = duration;
    saveSettings();
}
int FanController::getFanAutoSpeed() const { return fanAutoSpeed_; }
void FanController::setFanAutoSpeed(int speed) {
    fanAutoSpeed_ = speed;
    saveSettings();
}

// Private helper definitions
int FanController::smoothADCRead(int pin) {
    assert(pin >= 0 && pin < 40);
    int total = 0;
    // ADC_SAMPLES is a compile-time constant defined in parameters.h
    // providing a fixed upper bound for this loop
    for (int i = 0; i < ADC_SAMPLES; i++) { total += analogRead(pin); yield(); }
    return total / ADC_SAMPLES;
}

int FanController::getPositionFromADC(int v) {
    if (v > 3453) return 6;
    if (v > 2405) return 5;
    if (v > 1627) return 4;
    if (v > 1005) return 3;
    if (v >  394) return 2;
    return 1;
}

bool FanController::determineScheduleActive() {
    DateTime now = rtcHandler_.getTime();
    return (now.minute() < DEFAULT_FAN_DURATION);
}

void FanController::applyModeSettings(int pos, bool shouldRun) {
    int d = 0;
    switch (pos) {
      case 1: d = 0; strncpy(fanMode_, "Off", sizeof(fanMode_)); break;
      case 2: strncpy(fanMode_, "Auto", sizeof(fanMode_)); 
              d = shouldRun ? (DEFAULT_FAN_AUTOSPEED == 1 ? 150 : DEFAULT_FAN_AUTOSPEED == 2 ? 300 : DEFAULT_FAN_AUTOSPEED == 3 ? 512 : 1023) : 0;
              break;
      case 3: d = 150; strncpy(fanMode_, "Silent", sizeof(fanMode_)); break;
      case 4: d = 300; strncpy(fanMode_, "Low", sizeof(fanMode_)); break;
      case 5: d = 512; strncpy(fanMode_, "Medium", sizeof(fanMode_)); break;
      default: d = 1023; strncpy(fanMode_, "High", sizeof(fanMode_)); break;
    }
    fan1State_.targetDuty = fan2State_.targetDuty = d;
}

void FanController::applyWebOverride(bool shouldRun) {
    if (strcmp(webFanOverride_, "Off") == 0) applyModeSettings(1, false);
    else if (strcmp(webFanOverride_, "Auto") == 0) applyModeSettings(2, shouldRun);
    else if (strcmp(webFanOverride_, "Silent") == 0) applyModeSettings(3, false);
    else if (strcmp(webFanOverride_, "Low") == 0) applyModeSettings(4, false);
    else if (strcmp(webFanOverride_, "Medium") == 0) applyModeSettings(5, false);
    else applyModeSettings(6, false);
}

void FanController::rampFan(FanState &st, int channel) {
    unsigned long now = millis();
    if (now - st.lastUpdate < RAMP_STEP_INTERVAL) return;
    st.lastUpdate = now;
    if (st.currentDuty == st.targetDuty) return;
    st.currentDuty += (st.currentDuty < st.targetDuty) ? RAMP_STEP_SIZE : -RAMP_STEP_SIZE;
    if (st.currentDuty < 0) st.currentDuty = 0;
    if (st.currentDuty > 1023) st.currentDuty = 1023;
    ledcWrite(channel, st.currentDuty);
    fan1Speed_ = (channel==FAN_PWM_CHANNEL_1 ? st.currentDuty : fan1Speed_);
    fan2Speed_ = (channel==FAN_PWM_CHANNEL_2 ? st.currentDuty : fan2Speed_);
}

// Provide handleRotaryPositionChange helper
int FanController::handleRotaryPositionChange(int rotPin) {
    int adcVal = smoothADCRead(rotPin);
    int pos = getPositionFromADC(adcVal);
    bool changed = (pos != lastRotaryPosition_ && lastRotaryPosition_ != -1);
    if (changed) webFanOverride_[0] = '\0';
    lastRotaryPosition_ = pos;
    return pos;
}

void FanController::setWebFanOverride(const char* override) {
    strncpy(webFanOverride_, override, sizeof(webFanOverride_));
}

void FanController::loadSettings() {
    fanPrefs.begin("fan", true);
    fanDuration_ = fanPrefs.getInt("duration", DEFAULT_FAN_DURATION);
    fanAutoSpeed_ = fanPrefs.getInt("autospeed", DEFAULT_FAN_AUTOSPEED);
    fanPrefs.end();
}

void FanController::saveSettings() {
    fanPrefs.begin("fan", false);
    fanPrefs.putInt("duration", fanDuration_);
    fanPrefs.putInt("autospeed", fanAutoSpeed_);
    fanPrefs.end();
}
