#ifndef RTC_HANDLER_H
#define RTC_HANDLER_H

#include <RTClib.h>
#include <WiFi.h>
#include <time.h>

class RTCHandler {
private:
    RTC_DS3231 rtc;
    bool ntp_initialized = false;
    unsigned long last_sync_attempt = 0;
    const unsigned long SYNC_INTERVAL = 3600000; // Try to sync every hour
    const char* ntpServer = "pool.ntp.org";
    const long gmtOffset_sec = -18000;    // EST: UTC-5 * 3600
    const int daylightOffset_sec = 3600;  // 1 hour DST
    
    // Internal method to get time from NTP
    DateTime getTimeFromNTP();
    
    // Internal method to convert tm struct to DateTime
    DateTime tmToDateTime(struct tm *timeinfo);
    
public:
    RTCHandler();
    
    bool begin();
    void setTime(const DateTime& dt);
    DateTime getTime();
    bool isInitialized();
    
    // Method to sync RTC with NTP time
    bool syncWithNTP();
    
    // Existing helper methods
    bool isTimeInRange(uint8_t startHour, uint8_t startMinute, 
                      uint8_t endHour, uint8_t endMinute);
    bool isDayOfWeek(uint8_t dayOfWeek);
    bool isTimeBetween(uint8_t hour1, uint8_t minute1, 
                      uint8_t hour2, uint8_t minute2);
    bool hasElapsed(unsigned long &lastTime, unsigned long interval);
};

#endif // RTC_HANDLER_H