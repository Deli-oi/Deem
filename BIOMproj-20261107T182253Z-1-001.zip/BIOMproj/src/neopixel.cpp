#include "neopixel.h"
#include "water_level.h"
#include <Arduino.h>
#include <globals.h>
#include "parameters.h"

NeoPixel::NeoPixel()
    : pixel_(1, NEOPIXEL_PIN, NEO_GRB + NEO_KHZ800), previousBlinkMillis_(0), blinkInterval_(500), blinkState_(false) {}

void NeoPixel::setup() {
    pixel_.begin();
    pixel_.setBrightness(100);
    pixel_.setPixelColor(0, COLOR_WHITE);
    pixel_.show();
    delay(500);
    pixel_.setPixelColor(0, COLOR_RED);
    pixel_.show();
    delay(300);
    pixel_.setPixelColor(0, COLOR_GREEN);
    pixel_.show();
    delay(300);
    pixel_.setPixelColor(0, COLOR_BLUE);
    pixel_.show();
    delay(300);
    pixel_.clear();
    pixel_.show();
}

float NeoPixel::waterLevelPercentage() {
    float distance = constrain(waterLevel.getDistance(), WATER_FULL, WATER_EMPTY);
    return 100.0 * (WATER_EMPTY - distance) / WATER_RANGE;
}

void NeoPixel::update() {
    float percentage = waterLevelPercentage();
    unsigned long currentMillis = millis();
    uint32_t color;
    bool shouldBlink = false;
    if (waterLevel.getDistance() < WATER_FULL) {
        color = COLOR_RED;
        shouldBlink = true;
    } else if (percentage >= INDICATE_GREEN_PERCENT) {
        color = COLOR_GREEN;
    } else if (percentage >= INDICATE_YELLOW_PERCENT) {
        color = COLOR_YELLOW;
    } else if (percentage > 0.0) {
        color = COLOR_BLUE;
    } else {
        color = COLOR_BLUE;
        shouldBlink = true;
    }
    if (shouldBlink) {
        if (currentMillis - previousBlinkMillis_ >= blinkInterval_) {
            previousBlinkMillis_ = currentMillis;
            blinkState_ = !blinkState_;
        }
        if (!blinkState_) {
            color = 0;
        }
    }
    pixel_.setPixelColor(0, color);
    pixel_.show();
}
