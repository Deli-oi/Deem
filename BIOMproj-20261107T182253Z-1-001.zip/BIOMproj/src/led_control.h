// led_control.h
#ifndef LED_CONTROL_H
#define LED_CONTROL_H

#include <Arduino.h>
#include "parameters.h"

class LEDController {
  public:
    LEDController(int togglePin1, int togglePin2, int mosfetPin);
    void begin();
    void update();
    const char* mode() const;
    void setLedMode(const char* newMode);
    void setSchedule(int startHour, int stopHour);
    void loadSettings();
    void saveSettings();
    int getBrightness() const;  // Changed from brightness() to getBrightness()
    int getStartHour() const;   // Add this
    int getStopHour() const;    // Add this
    void setWebLEDOverride(const char* override);  // Add this

  private:
    int togglePin1_;
    int togglePin2_;
    int mosfetPin_;
    char ledMode_[10];
    int ledBrightness_;
    char webLEDOverride_[10];
    int lastToggleState1_;
    int lastToggleState2_;
    int startHour_;
    int stopHour_;

    void handleToggle(int s1, int s2);
    int computeBrightness();
    void driveChannel(int value);
};

extern LEDController ledCtl;

#endif // LED_CONTROL_H
