#ifndef GLOBALS_H
#define GLOBALS_H

#include "led_control.h"
#include "pump_control.h"
#include "fan_control.h"
#include "rtc_handler.h"
#include "iaq_sensors.h"
#include "water_level.h"
#include "neopixel.h"
#include "wifi_app.h"
#include "parameters.h"

// Pin definitions
#define LED_INPUT_PIN_1 4
#define LED_INPUT_PIN_2 21
#define LED_MOSFET_PIN 15
#define PUMP_TOGGLE_PIN_1 19
#define PUMP_TOGGLE_PIN_2 5
#define PUMP_MOSFET_PIN 33
#define ROTARY_ADC_PIN 34
#define FAN_OUTPUT_PWM_1 27
#define FAN_OUTPUT_PWM_2 13
#define TACH_PIN1 25
#define TACH_PIN2 39
#define NEOPIXEL_POWER 2

// Global instances
extern LEDController ledCtl;
extern PumpController pumpCtl;
extern IAQSensors iaqSensors;
extern RTCHandler rtcHandler;
extern FanController fanCtl;
extern WaterLevel waterLevel;
extern NeoPixel neoPixel;
extern Wifi wifi;

#endif // GLOBALS_H
