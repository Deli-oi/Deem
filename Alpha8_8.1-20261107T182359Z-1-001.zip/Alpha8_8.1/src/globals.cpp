#include "globals.h"

// Define global instances
LEDController ledCtl(LED_INPUT_PIN_1, LED_INPUT_PIN_2, LED_MOSFET_PIN);
PumpController pumpCtl(PUMP_TOGGLE_PIN_1, PUMP_TOGGLE_PIN_2, PUMP_MOSFET_PIN);
IAQSensors iaqSensors;
RTCHandler rtcHandler;
FanController fanCtl(FAN_OUTPUT_PWM_1, FAN_OUTPUT_PWM_2, TACH_PIN1, TACH_PIN2, ROTARY_ADC_PIN, rtcHandler);
WaterLevel waterLevel;
NeoPixel neoPixel;
Wifi wifi;  // Add global WiFi instance
